-- =====================================================================
-- 01_create_database.sql  -  create the project database
-- LuxDevHQ Cohort 9 - Advanced SQL (SokoMart Kenya)
--
-- CREATE DATABASE cannot run inside a transaction block, so run this file
-- ON ITS OWN, connected to any existing database (usually "postgres"):
--
--     psql -d postgres -f 01_create_database.sql
--
-- Then connect to the new database for every other file:
--
--     \c luxdevhq_cohort9_advanced_sql          (inside psql)
--     psql -d luxdevhq_cohort9_advanced_sql ... (from the shell)
--
-- Host, port and user come from psql flags (-h -p -U) or the PGHOST /
-- PGPORT / PGUSER / PGPASSWORD environment variables. No credentials are
-- stored in this project.
--
-- If the database already exists this file stops with an error and changes
-- nothing. To start again, use 07_reset_database.sql (it only resets the
-- sokomart schema) or drop the database yourself.
-- =====================================================================

CREATE DATABASE luxdevhq_cohort9_advanced_sql
    WITH ENCODING 'UTF8'
         TEMPLATE template0;

COMMENT ON DATABASE luxdevhq_cohort9_advanced_sql IS
    'LuxDevHQ Cohort 9 Advanced SQL project - SokoMart Kenya (synthetic data)';
