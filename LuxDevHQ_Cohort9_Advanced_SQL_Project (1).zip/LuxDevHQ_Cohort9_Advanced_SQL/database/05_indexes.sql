-- =====================================================================
-- 05_indexes.sql  -  secondary indexes (access paths)
--
-- Kept OUT of 03_create_tables.sql on purpose: for Questions 21-22 you run
-- EXPLAIN ANALYZE on a query BEFORE this file, run this file, and run the
-- same EXPLAIN ANALYZE again to compare the plans.
--
-- Primary keys and UNIQUE constraints already have indexes. Postgres does
-- NOT index foreign-key columns automatically - most of the indexes below are
-- exactly those join columns.
--
-- Safe to re-run (IF NOT EXISTS). To go back to "before", run the DROP block
-- at the bottom (commented out).
-- =====================================================================
\set ON_ERROR_STOP on
SET search_path TO sokomart, public;

-- customer access paths
CREATE INDEX IF NOT EXISTS idx_customers_county            ON sokomart.customers (county);
CREATE INDEX IF NOT EXISTS idx_customers_registration_date ON sokomart.customers (registration_date);

-- product access paths
CREATE INDEX IF NOT EXISTS idx_products_category           ON sokomart.products (category);

-- order access paths
CREATE INDEX IF NOT EXISTS idx_orders_customer_id          ON sokomart.orders (customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_order_date           ON sokomart.orders (order_date);
CREATE INDEX IF NOT EXISTS idx_orders_status_date          ON sokomart.orders (order_status, order_date);
CREATE INDEX IF NOT EXISTS idx_orders_customer_date        ON sokomart.orders (customer_id, order_date);

-- order item access paths (uq_order_items_order_product already covers order_id lookups)
CREATE INDEX IF NOT EXISTS idx_order_items_product_id      ON sokomart.order_items (product_id);

-- payment access paths
CREATE INDEX IF NOT EXISTS idx_payments_order_id           ON sokomart.payments (order_id);
CREATE INDEX IF NOT EXISTS idx_payments_status_method      ON sokomart.payments (payment_status, payment_method);
CREATE INDEX IF NOT EXISTS idx_payments_payment_date       ON sokomart.payments (payment_date);

-- history tables
CREATE INDEX IF NOT EXISTS idx_price_history_product_id    ON sokomart.product_price_history (product_id);
CREATE INDEX IF NOT EXISTS idx_status_history_order_id     ON sokomart.order_status_history (order_id);

ANALYZE sokomart.customers, sokomart.products, sokomart.orders,
        sokomart.order_items, sokomart.payments;

\echo 05_indexes.sql finished

-- ---------------------------------------------------------------------
-- To return to the "no secondary indexes" state for a before/after test:
-- DROP INDEX IF EXISTS sokomart.idx_customers_county, sokomart.idx_customers_registration_date,
--     sokomart.idx_products_category, sokomart.idx_orders_customer_id, sokomart.idx_orders_order_date,
--     sokomart.idx_orders_status_date, sokomart.idx_orders_customer_date,
--     sokomart.idx_order_items_product_id, sokomart.idx_payments_order_id,
--     sokomart.idx_payments_status_method, sokomart.idx_payments_payment_date,
--     sokomart.idx_price_history_product_id, sokomart.idx_status_history_order_id;
-- ---------------------------------------------------------------------
