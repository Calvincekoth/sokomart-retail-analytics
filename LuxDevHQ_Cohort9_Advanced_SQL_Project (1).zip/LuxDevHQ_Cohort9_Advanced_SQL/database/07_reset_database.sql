-- =====================================================================
-- 07_reset_database.sql  -  start again from an empty sokomart schema
--
-- WHAT IT DOES: drops the schema "sokomart" in the database you are
-- connected to - every table, view, materialized view, function, procedure
-- and trigger you created in it - and recreates the empty schema.
--
-- WHAT IT DOES NOT DO: it never drops a database and never touches any
-- other schema or any other database. It refuses to run unless you are
-- connected to luxdevhq_cohort9_advanced_sql.
--
-- Afterwards reload in order, from the database/ folder:
--     psql -d luxdevhq_cohort9_advanced_sql -f 07_reset_database.sql
--     psql -d luxdevhq_cohort9_advanced_sql -f 03_create_tables.sql
--     psql -d luxdevhq_cohort9_advanced_sql -f 04_insert_data.sql
--     psql -d luxdevhq_cohort9_advanced_sql -f 05_indexes.sql
--     psql -d luxdevhq_cohort9_advanced_sql -f 06_validation.sql
-- (02_create_schema.sql is not needed again - this file recreates the schema.)
-- =====================================================================
\set ON_ERROR_STOP on

DO $$
BEGIN
    IF current_database() <> 'luxdevhq_cohort9_advanced_sql' THEN
        RAISE EXCEPTION 'Refusing to reset: connected to database "%", expected luxdevhq_cohort9_advanced_sql',
            current_database();
    END IF;
END $$;

BEGIN;
DROP SCHEMA IF EXISTS sokomart CASCADE;
CREATE SCHEMA sokomart;
COMMENT ON SCHEMA sokomart IS 'SokoMart Kenya e-commerce data (synthetic, for teaching)';
COMMIT;

SET search_path TO sokomart, public;
\echo sokomart schema reset - now run 03, 04, 05 and 06
