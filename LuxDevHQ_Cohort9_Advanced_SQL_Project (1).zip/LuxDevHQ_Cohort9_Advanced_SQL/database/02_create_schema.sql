-- =====================================================================
-- 02_create_schema.sql  -  create the sokomart schema
-- Run connected to luxdevhq_cohort9_advanced_sql:
--     psql -d luxdevhq_cohort9_advanced_sql -f 02_create_schema.sql
-- =====================================================================
\set ON_ERROR_STOP on

CREATE SCHEMA IF NOT EXISTS sokomart;
COMMENT ON SCHEMA sokomart IS 'SokoMart Kenya e-commerce data (synthetic, for teaching)';

-- Make sokomart the default for this database, so students can write
-- "FROM orders" instead of "FROM sokomart.orders" in new sessions.
-- (Fully-qualified names are still used throughout the project files.)
DO $$
BEGIN
    EXECUTE format('ALTER DATABASE %I SET search_path TO sokomart, public', current_database());
END $$;

SET search_path TO sokomart, public;
