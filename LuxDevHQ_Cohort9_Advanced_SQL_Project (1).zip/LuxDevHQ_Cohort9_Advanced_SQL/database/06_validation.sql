-- =====================================================================
-- 06_validation.sql  -  prove the load is complete and consistent
-- Run after 04_insert_data.sql (and 05_indexes.sql):
--     psql -d luxdevhq_cohort9_advanced_sql -f 06_validation.sql
--
-- Prints one row per check with PASS or FAIL, then a summary line.
-- Every check should PASS on a fresh load. Run it on a FRESH load: once you
-- start the Section D exercises (sp_place_order creates new orders dated
-- today) the date-range checks are expected to report those new rows.
--
-- The expected counts are those of the default full dataset. If you
-- generated a different size with --customers/--orders/... the count checks
-- will FAIL by design while every integrity check should still PASS.
-- =====================================================================
\set ON_ERROR_STOP on
SET search_path TO sokomart, public;
\pset footer off

-- The checks live in a TEMPORARY view (gone when you disconnect, writes nothing
-- to the sokomart schema) so the summary below can count PASS/FAIL rows.
CREATE OR REPLACE TEMP VIEW validation_checks (check_no, check_group, check_name, expected, actual) AS
    -- 1. Record counts --------------------------------------------------
    SELECT  1, 'counts', 'customers rows',     '5000',   (SELECT COUNT(*) FROM sokomart.customers)::text UNION ALL
    SELECT  2, 'counts', 'products rows',      '300',    (SELECT COUNT(*) FROM sokomart.products)::text UNION ALL
    SELECT  3, 'counts', 'orders rows',        '50000',  (SELECT COUNT(*) FROM sokomart.orders)::text UNION ALL
    SELECT  4, 'counts', 'order_items rows',   '120000', (SELECT COUNT(*) FROM sokomart.order_items)::text UNION ALL
    SELECT  5, 'counts', 'payments rows',      '50000',  (SELECT COUNT(*) FROM sokomart.payments)::text UNION ALL
    SELECT  6, 'counts', 'core total (5 tables)', '225300',
        ((SELECT COUNT(*) FROM sokomart.customers) + (SELECT COUNT(*) FROM sokomart.products)
       + (SELECT COUNT(*) FROM sokomart.orders) + (SELECT COUNT(*) FROM sokomart.order_items)
       + (SELECT COUNT(*) FROM sokomart.payments))::text UNION ALL
    SELECT  7, 'counts', 'payment_staging has rows', '> 0',
        CASE WHEN EXISTS (SELECT 1 FROM sokomart.payment_staging) THEN '> 0' ELSE '0' END UNION ALL

    -- 2. Referential integrity (the FKs enforce these; re-checked explicitly)
    SELECT  8, 'integrity', 'orders without a customer', '0',
        (SELECT COUNT(*) FROM sokomart.orders o
          WHERE NOT EXISTS (SELECT 1 FROM sokomart.customers c WHERE c.customer_id = o.customer_id))::text UNION ALL
    SELECT  9, 'integrity', 'order_items without an order', '0',
        (SELECT COUNT(*) FROM sokomart.order_items i
          WHERE NOT EXISTS (SELECT 1 FROM sokomart.orders o WHERE o.order_id = i.order_id))::text UNION ALL
    SELECT 10, 'integrity', 'order_items without a product', '0',
        (SELECT COUNT(*) FROM sokomart.order_items i
          WHERE NOT EXISTS (SELECT 1 FROM sokomart.products p WHERE p.product_id = i.product_id))::text UNION ALL
    SELECT 11, 'integrity', 'payments without an order', '0',
        (SELECT COUNT(*) FROM sokomart.payments p
          WHERE NOT EXISTS (SELECT 1 FROM sokomart.orders o WHERE o.order_id = p.order_id))::text UNION ALL
    SELECT 12, 'integrity', 'staging rows pointing at unknown orders', '0',
        (SELECT COUNT(*) FROM sokomart.payment_staging s
          WHERE NOT EXISTS (SELECT 1 FROM sokomart.orders o WHERE o.order_id = s.order_id))::text UNION ALL

    -- 3. Duplicate keys -------------------------------------------------
    SELECT 13, 'duplicates', 'duplicate customer_id', '0',
        (SELECT COUNT(*) - COUNT(DISTINCT customer_id) FROM sokomart.customers)::text UNION ALL
    SELECT 14, 'duplicates', 'duplicate product_id', '0',
        (SELECT COUNT(*) - COUNT(DISTINCT product_id) FROM sokomart.products)::text UNION ALL
    SELECT 15, 'duplicates', 'duplicate order_id', '0',
        (SELECT COUNT(*) - COUNT(DISTINCT order_id) FROM sokomart.orders)::text UNION ALL
    SELECT 16, 'duplicates', 'duplicate order_item_id', '0',
        (SELECT COUNT(*) - COUNT(DISTINCT order_item_id) FROM sokomart.order_items)::text UNION ALL
    SELECT 17, 'duplicates', 'duplicate payment_id', '0',
        (SELECT COUNT(*) - COUNT(DISTINCT payment_id) FROM sokomart.payments)::text UNION ALL
    SELECT 18, 'duplicates', 'duplicate customer emails', '0',
        (SELECT COUNT(*) - COUNT(DISTINCT lower(email)) FROM sokomart.customers)::text UNION ALL

    -- 4. Missing mandatory values ----------------------------------------
    SELECT 19, 'mandatory', 'customers missing name/email/county/status', '0',
        (SELECT COUNT(*) FROM sokomart.customers
          WHERE first_name IS NULL OR last_name IS NULL OR email IS NULL OR county IS NULL
             OR registration_date IS NULL OR customer_status IS NULL
             OR trim(first_name) = '' OR trim(last_name) = '')::text UNION ALL
    SELECT 20, 'mandatory', 'products missing name/category/prices', '0',
        (SELECT COUNT(*) FROM sokomart.products
          WHERE product_name IS NULL OR category IS NULL OR unit_price IS NULL OR cost_price IS NULL)::text UNION ALL
    SELECT 21, 'mandatory', 'orders missing date/status/county/amounts', '0',
        (SELECT COUNT(*) FROM sokomart.orders
          WHERE order_date IS NULL OR order_status IS NULL OR shipping_county IS NULL
             OR delivery_fee IS NULL OR total_amount IS NULL)::text UNION ALL
    SELECT 22, 'mandatory', 'successful/failed non-cash payments missing a reference', '0',
        (SELECT COUNT(*) FROM sokomart.payments
          WHERE transaction_reference IS NULL AND payment_method <> 'cash on delivery')::text UNION ALL

    -- 5. Financial consistency -------------------------------------------
    SELECT 23, 'financial', 'line_total <> round(qty*price*(1-disc/100),2)', '0',
        (SELECT COUNT(*) FROM sokomart.order_items
          WHERE line_total <> ROUND(quantity * unit_price * (1 - discount_percentage / 100), 2))::text UNION ALL
    SELECT 24, 'financial', 'orders where total <> SUM(line_total) + delivery_fee', '0',
        (SELECT COUNT(*) FROM sokomart.orders o
          LEFT JOIN (SELECT order_id, SUM(line_total) AS items_total
                       FROM sokomart.order_items GROUP BY order_id) i USING (order_id)
          WHERE o.total_amount <> COALESCE(i.items_total, 0) + o.delivery_fee)::text UNION ALL
    SELECT 25, 'financial', 'orders with no order_items', '0',
        (SELECT COUNT(*) FROM sokomart.orders o
          WHERE NOT EXISTS (SELECT 1 FROM sokomart.order_items i WHERE i.order_id = o.order_id))::text UNION ALL
    SELECT 26, 'financial', 'products priced at or below zero', '0',
        (SELECT COUNT(*) FROM sokomart.products WHERE unit_price <= 0)::text UNION ALL

    -- 6. Order / payment consistency -------------------------------------
    SELECT 27, 'order-payment', 'orders without exactly one payment', '0',
        (SELECT COUNT(*) FROM sokomart.orders o
          WHERE (SELECT COUNT(*) FROM sokomart.payments p WHERE p.order_id = o.order_id) <> 1)::text UNION ALL
    SELECT 28, 'order-payment', 'payment amount <> order total_amount', '0',
        (SELECT COUNT(*) FROM sokomart.payments p JOIN sokomart.orders o USING (order_id)
          WHERE p.amount <> o.total_amount)::text UNION ALL
    SELECT 29, 'order-payment', 'completed orders whose payment is not successful', '0',
        (SELECT COUNT(*) FROM sokomart.orders o JOIN sokomart.payments p USING (order_id)
          WHERE o.order_status = 'completed' AND p.payment_status <> 'successful')::text UNION ALL
    SELECT 30, 'order-payment', 'cancelled orders with a successful payment', '0',
        (SELECT COUNT(*) FROM sokomart.orders o JOIN sokomart.payments p USING (order_id)
          WHERE o.order_status = 'cancelled' AND p.payment_status = 'successful')::text UNION ALL
    SELECT 31, 'order-payment', 'payments dated before their order', '0',
        (SELECT COUNT(*) FROM sokomart.payments p JOIN sokomart.orders o USING (order_id)
          WHERE p.payment_date < o.order_date)::text UNION ALL

    -- 7. Date ranges ----------------------------------------------------
    SELECT 32, 'dates', 'orders outside 2025-01-01 .. 2026-10-31', '0',
        (SELECT COUNT(*) FROM sokomart.orders
          WHERE order_date < '2025-01-01' OR order_date >= '2026-11-01')::text UNION ALL
    SELECT 33, 'dates', 'payments outside 2025-01-01 .. 2026-10-31', '0',
        (SELECT COUNT(*) FROM sokomart.payments
          WHERE payment_date < '2025-01-01' OR payment_date >= '2026-11-01')::text UNION ALL
    SELECT 34, 'dates', 'orders placed before the customer registered', '0',
        (SELECT COUNT(*) FROM sokomart.orders o JOIN sokomart.customers c USING (customer_id)
          WHERE o.order_date::date < c.registration_date)::text UNION ALL
    SELECT 35, 'dates', 'products sold before they were created', '0',
        (SELECT COUNT(*) FROM sokomart.order_items i
           JOIN sokomart.orders o USING (order_id) JOIN sokomart.products p USING (product_id)
          WHERE o.order_date < p.created_at)::text UNION ALL
    SELECT 36, 'dates', 'registration dates in the future', '0',
        (SELECT COUNT(*) FROM sokomart.customers WHERE registration_date > CURRENT_DATE)::text UNION ALL

    -- 8. Teaching data present (each Section's questions depend on these)
    SELECT 37, 'teaching', 'customers who never ordered (Q12/Q16 edge case)', '> 0',
        CASE WHEN EXISTS (SELECT 1 FROM sokomart.customers c
                           WHERE NOT EXISTS (SELECT 1 FROM sokomart.orders o WHERE o.customer_id = c.customer_id))
             THEN '> 0' ELSE '0' END UNION ALL
    SELECT 38, 'teaching', 'products never sold (Q5)', '> 0',
        CASE WHEN EXISTS (SELECT 1 FROM sokomart.products p
                           WHERE NOT EXISTS (SELECT 1 FROM sokomart.order_items i WHERE i.product_id = p.product_id))
             THEN '> 0' ELSE '0' END UNION ALL
    SELECT 39, 'teaching', 'duplicate payments in payment_staging (Q24)', '> 0',
        CASE WHEN EXISTS (SELECT 1 FROM sokomart.payment_staging
                           GROUP BY payment_id, transaction_reference, amount HAVING COUNT(*) > 1)
             THEN '> 0' ELSE '0' END UNION ALL
    SELECT 40, 'teaching', 'all three payment statuses present (Q13)', '3',
        (SELECT COUNT(DISTINCT payment_status) FROM sokomart.payments)::text UNION ALL
    SELECT 41, 'teaching', 'all four order statuses present', '4',
        (SELECT COUNT(DISTINCT order_status) FROM sokomart.orders)::text
;

SELECT check_no, check_group, check_name, expected, actual,
       CASE WHEN expected = actual THEN 'PASS' ELSE 'FAIL' END AS result
FROM validation_checks
ORDER BY check_no;

-- One-line summary
SELECT COUNT(*) FILTER (WHERE expected = actual)  AS checks_passed,
       COUNT(*) FILTER (WHERE expected <> actual) AS checks_failed,
       CASE WHEN COUNT(*) FILTER (WHERE expected <> actual) = 0
            THEN 'ALL CHECKS PASSED' ELSE 'SOME CHECKS FAILED - read the FAIL rows above' END AS summary
FROM validation_checks;
