# Submission guidelines — SokoMart Kenya Advanced SQL Project

**Deadline: Thursday 12 November 2026, 11:59 PM EAT.**
Submit on **Squad → Project Lab** (the *Advanced SQL — SokoMart Kenya* project). Late work
follows the cohort's late-submission policy.

## What you submit

One link: a **public GitHub repository**. Before you paste it into Squad, open it in a private
/ incognito browser window — if you cannot see the files there, the marker cannot either.

The repository must contain:

1. **Your SQL** — one file per section (or one per question, if you prefer), each runnable from
   top to bottom on a fresh load.
2. **A `README.md`** — how to run your work, and your business insights (below).
3. **Screenshots** of the result of every question (and of the error message where a question
   asks you to show one).
4. **A business insights and recommendations section** in the README.

Do **not** commit the SokoMart CSV files or the database dump — they are large and everyone has
them. Do commit your own SQL, README and screenshots.

## Repository layout

```
sokomart-advanced-sql/              <- any name; make it public
├── README.md
├── sql/
│   ├── 00_practice_drills.sql      (unmarked, but include it)
│   ├── section_a_ctes_subqueries.sql
│   ├── section_b_window_functions.sql
│   ├── section_c_advanced_aggregation.sql
│   ├── section_d_views_functions_procedures.sql
│   └── section_e_optimisation_transactions.sql
└── screenshots/
    ├── q01_big_spenders_2025.png
    ├── q02_premium_products.png
    ├── ...
    └── q25_three_month_streaks.png
```

One file per question (`sql/q01.sql` … `sql/q25.sql`) is equally fine. Whatever you choose:

- Start every question with a comment header:
  ```sql
  -- =============================================================
  -- Q7. Best sellers per category, 2025   (ROW_NUMBER)
  -- Result: 15 rows  (screenshot: screenshots/q07_best_sellers_2025.png)
  -- =============================================================
  ```
- Write the **row count you got** in that header. Markers compare it with the expected result.
- Name screenshots `qNN_short_name.png` (two-digit numbers so they sort).
- Long results (hundreds of rows): screenshot the first rows **and** the row-count line / the
  summary query the question asks for.

## README.md must include

1. **Title and your name** (as on Squad), cohort, date.
2. **How to run** — which order to run your SQL files in, and that they expect the SokoMart
   database loaded with `03 → 04 → 05` from the project package (link `docs/database_setup.md`
   in your own words; do not include passwords).
3. **A results table** — question, file, row count, screenshot link. For example:

   | Q | File | Rows | Screenshot |
   |---|---|---|---|
   | 1 | `sql/section_a_ctes_subqueries.sql` | 10 (top) / NNN above avg | [q01](screenshots/q01_big_spenders_2025.png) |

4. **Business insights and recommendations** — 5 to 8 short points, each backed by a number
   from **your** results and the question it came from. For example (do not copy — use your numbers):
   - *"December is SokoMart's biggest month: revenue was X, Y% above November (Q8). Recommend
     stocking electronics from mid-October."*
   - *"Fashion earns less revenue than Home Appliances but more gross profit (Q14) because its margin
     is about Z%."*
   - *"M-Pesa failures cost KES … in 2026 (Q13)."*
   Finish with one paragraph: the single change you would make first, and why.
5. **What you found hard** — two or three sentences (optional, but it helps us teach Cohort 10).

## Before you submit — checklist

- [ ] Every SQL file runs top to bottom on a fresh load (`07_reset_database.sql`, then `03`, `04`, `05`).
- [ ] Each question has its header comment with the row count.
- [ ] Every question has a screenshot, and the README links to it.
- [ ] The README has the insights and recommendations section.
- [ ] No passwords, `.env` files or connection strings with passwords anywhere in the repo.
- [ ] No CSV / dump files committed.
- [ ] The repository is **public** and opens in an incognito window.
- [ ] You pasted the repository URL into Squad → Project Lab **before 11:59 PM EAT on Thursday 12 November 2026**.

## How it is marked

100 marks across the 25 questions (see the marks column in `advanced_sql_questions.md`). For each
question, roughly: half for the correct result, a quarter for actually using the required concept
(e.g. a correlated subquery in Q2, a procedure that is `CALL`ed in Q18–Q20), a quarter for clean,
readable, re-runnable SQL with its screenshot. The insights section is part of the README and can
lift a borderline grade. Work that is copied — from another student or generated without your
understanding — scores zero for the questions concerned; be ready to explain any query you submit.
