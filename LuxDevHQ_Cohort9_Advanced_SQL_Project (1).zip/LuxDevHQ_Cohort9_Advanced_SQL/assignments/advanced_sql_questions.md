# SokoMart Kenya — Advanced SQL Practical Project

**LuxDevHQ Data Engineering / Data Analytics — Cohort 9**
**Dates:** Monday 9 November – Thursday 12 November 2026
**Deadline:** **Thursday 12 November 2026, 11:59 PM EAT** (submit on Squad → Project Lab)
**Total:** 100 marks (25 questions) + 10 unmarked practice drills

You are a data analyst at **SokoMart Kenya**, an online shop selling electronics,
groceries, fashion, home appliances and beauty products across Kenya. Every question
below is a real request from someone in the business. For each one you **write the
SQL, run it against the SokoMart database, and save the result** (a screenshot and,
where asked, a row count). No question asks you to describe or explain a concept in
words — the SQL and its result are the answer.

The company, the people and every record in the database are synthetic.

---

## The 4-day plan

| Day | Date | Work | Questions |
|---|---|---|---|
| 1 | **Monday 9 Nov** | Set up the database (`docs/database_setup.md`), run `06_validation.sql` until every row says PASS. Morning: the 10 **practice drills**. Afternoon: **Section A**. Create your GitHub repo. | Drills, Q1–Q5 |
| 2 | **Tuesday 10 Nov** | **Section B** — window functions. | Q6–Q10 |
| 3 | **Wednesday 11 Nov** | **Section C** — advanced aggregation with subqueries; **Section D** — views, functions, stored procedures, triggers. | Q11–Q20 |
| 4 | **Thursday 12 Nov** | **Section E** — optimisation and transactions. Write your README, the business insights section, tidy the screenshots, push, and submit on Squad **by 11:59 PM EAT**. | Q21–Q25 |

Commit at the end of every day. A repo with four days of commits is easier to trust
than one giant commit at 11:58 PM.

---

## Rules that apply to every question

1. **The revenue rule.** *Revenue* means `SUM(order_items.line_total)` for orders whose
   `order_status = 'completed'`. Delivery fees are **not** revenue. Pending, cancelled
   and returned orders are **not** revenue. `payments.amount` is for payment analysis
   (Q13, Q24) — never use it as revenue.
2. **Cost and profit.** *Cost* = `SUM(order_items.quantity * products.cost_price)` for the
   same order lines. *Gross profit* = revenue − cost. *Margin %* = 100 × gross profit ÷ revenue.
3. **Months** are calendar months of `orders.order_date`: `DATE_TRUNC('month', order_date)`.
   Show them as `YYYY-MM` unless the question says otherwise.
4. **Date ranges** are half-open: `order_date >= '2025-01-01' AND order_date < '2026-01-01'`.
   `BETWEEN '2025-01-01' AND '2025-12-31'` silently drops everything after midnight on
   31 December, because `order_date` is a timestamp.
5. **A customer's county** is `customers.county` (where they live) unless the question says
   *shipping county* (`orders.shipping_county`, where that order was delivered).
6. **Full name** = `first_name || ' ' || last_name`.
7. Money is `NUMERIC`. Round percentages to 2 decimal places. Do not cast money to `FLOAT`.
8. Use the column names given under **Expected output** exactly, in that order. Where the
   question says *order by*, order that way.
9. Every SQL file must run from top to bottom on a fresh load without errors (except
   where a question asks you to show an error on purpose).
10. Sections D and E change data. Before you take final screenshots of Sections A–C,
    or if you get into a mess, reset with `07_reset_database.sql` and reload
    (see `docs/database_setup.md`).

---

## Practice drills (Monday morning — unmarked)

Quick warm-ups for the three ideas this project is built on: **subqueries, CTEs and
stored procedures**. Do them before Section A. They are not marked, but put them in
`sql/00_practice_drills.sql` in your repo — markers look at them when a Section A
answer is borderline.

| # | Task | Concept | Expected output |
|---|---|---|---|
| D1 | List the products whose `unit_price` is above the average `unit_price` of **all** products. Show the 10 most expensive, then on a second query the count. | Scalar subquery in `WHERE` and `SELECT` | `product_id, product_name, category, unit_price, overall_avg_price`; then one number |
| D2 | List customers living in **Mombasa** who placed at least one order (any status) in **December 2025**. | `IN (subquery)` | `customer_id, first_name, last_name, email`; then the count |
| D3 | How many customers living in **Kisumu** have at least one payment with `payment_status = 'failed'`? | `EXISTS` correlated subquery | `kisumu_customers_with_failed_payment` (one number) |
| D4 | For each `order_status`, show the number of orders, the average number of lines per order and the average number of units per order. Compute the per-order figures in a subquery in `FROM`. | Derived table | `order_status, orders, avg_lines_per_order, avg_units_per_order` |
| D5 | Top 5 **shipping counties** by number of completed orders in 2026. Put the filtered orders in a CTE. | Single CTE | `shipping_county, completed_orders` |
| D6 | For 2025: completed orders per month, the 2025 monthly average, and whether each month is `above average` or `at/below average`. Use two CTEs (monthly counts, then the stats). | Chained CTEs | `month, completed_orders, avg_per_month, vs_average` (12 rows) |
| D7 | Write `sokomart.fn_order_count(p_customer_id INTEGER) RETURNS INTEGER` — the number of orders (any status) a customer has. Call it for customer **177** and for a customer that does not exist (`-1`). | SQL function | two numbers |
| D8 | Write `sokomart.sp_set_customer_status(p_customer_id INTEGER, p_status VARCHAR)`. It raises an exception for a status other than `active / inactive / suspended`, and for a customer that does not exist. Inside `BEGIN … ROLLBACK`, set customer **177** to `suspended`, show it, roll back, show it is `active` again. Then show the exception for status `'vip'`. | Stored procedure, `RAISE EXCEPTION`, `CALL` | the three status checks + the error message |
| D9 | Beauty products whose `stock_quantity` is below the **average Beauty stock**. Put the Beauty products in a CTE and compare with a scalar subquery on that CTE. | CTE + scalar subquery | `product_id, product_name, stock_quantity, beauty_avg_stock` |
| D10 | Write `sokomart.sp_county_summary(IN p_county VARCHAR, OUT p_customers INTEGER, OUT p_revenue NUMERIC)` returning the number of customers living in the county and their completed revenue. `CALL sokomart.sp_county_summary('Nakuru', NULL, NULL);` | Procedure with `OUT` parameters | `p_customers, p_revenue` (one row) |

---

## Section A — CTEs and subqueries (20 marks)

### Question 1 — Big spenders of 2025 *(4 marks · Medium)*

**Scenario.** Marketing wants to invite 2025's above-average customers to a loyalty launch.
**Task.** In a CTE, compute each customer's **2025 revenue** (completed orders placed in 2025).
List the customers whose 2025 revenue is **above the average 2025 revenue of customers who
bought in 2025**. Get the average with a subquery (or a second CTE) over the first CTE — not
a hard-coded number. Order by `total_spent_2025` descending. Then, in a second query, give
the number of customers who bought in 2025, the average, and the number of rows your main
query returns.
**Required concept.** CTE + scalar subquery over the CTE.
**Expected output.** `customer_id, full_name, county, total_spent_2025, avg_spent_2025, amount_above_avg`

### Question 2 — Premium-priced products *(4 marks · Medium)*

**Scenario.** The pricing team wants every **active** product that is priced above the average
price of **its own category**.
**Task.** Use a **correlated subquery** that computes the category average for each product's
category (average over all products in the category, any status). Show the gap. Order by
category, then `price_gap` descending. Add a second query counting the rows per category.
**Required concept.** Correlated subquery (in `WHERE` and in `SELECT`). No window functions.
**Expected output.** `product_id, product_name, category, unit_price, category_avg_price, price_gap`

### Question 3 — 2026 monthly profit and loss *(4 marks · Medium)*

**Scenario.** Finance needs a monthly P&L for **January–October 2026**.
**Task.** Build it with **at least three chained CTEs**: (1) the completed order lines with
their month and line cost; (2) monthly revenue and cost; (3) gross profit. Final `SELECT` adds
the margin. One row per month, in month order.
**Required concept.** Multiple chained CTEs.
**Expected output.** `month, revenue, cost, gross_profit, margin_pct` (10 rows)

### Question 4 — Cross-category shoppers in Nakuru *(4 marks · Medium)*

**Scenario.** The Nakuru regional manager wants customers who already shop across several
departments, for a bundle campaign.
**Task.** In a **derived table** (a subquery in `FROM`), compute for every customer the number of
distinct product categories in their completed orders and their total revenue. Join it to
`customers` and keep customers **living in Nakuru** with **3 or more** categories. Order by
`category_count` descending, then `total_spent` descending. Second query: how many Nakuru
customers qualify, and how many of them bought from **all five** categories.
**Required concept.** Derived table, `COUNT(DISTINCT …)`.
**Expected output.** `customer_id, full_name, county, category_count, total_spent`

### Question 5 — Products nobody has ordered *(4 marks · Easy)*

**Scenario.** The warehouse is reviewing shelf space: which products have **never appeared on
any order** (any status)?
**Task.** Use `NOT EXISTS` (or `LEFT JOIN … IS NULL`). **`NOT IN` is not allowed** — it returns
nothing at all if the subquery ever yields a NULL. Order by category, then product name.
**Required concept.** Anti-join with `NOT EXISTS`.
**Expected output.** `product_id, product_name, category, product_status, stock_quantity, created_at`

---

## Section B — Window functions (20 marks)

### Question 6 — County leaderboards *(4 marks · Medium)*

**Scenario.** Each county manager wants their top 3 customers by lifetime revenue.
**Task.** Compute every customer's lifetime revenue (completed orders), rank customers **within
their county** with `DENSE_RANK()`, and keep ranks 1–3. Order by county, rank, customer_id.
**Required concept.** `DENSE_RANK() OVER (PARTITION BY … ORDER BY …)` over a CTE.
**Expected output.** `county, county_rank, customer_id, full_name, total_spent`

### Question 7 — Best sellers per category, 2025 *(4 marks · Medium)*

**Scenario.** Category buyers are planning 2026 stock and want 2025's top 3 products in each category.
**Task.** 2025 revenue and units sold per product (completed orders in 2025), numbered within
category by revenue with `ROW_NUMBER()` (tie-break on `product_id`). Keep 1–3.
**Required concept.** `ROW_NUMBER()` top-N per group.
**Expected output.** `category, rank_in_category, product_id, product_name, revenue, units_sold` (15 rows)

### Question 8 — Month-over-month growth *(4 marks · Medium)*

**Scenario.** The CEO's dashboard shows revenue growth versus the previous month.
**Task.** Monthly revenue for every month in the data (January 2025 – October 2026), the
previous month's revenue with `LAG()`, and growth %. The first month has no previous month (NULL).
**Required concept.** `LAG()`, `NULLIF` to avoid division by zero.
**Expected output.** `month, revenue, prev_month_revenue, growth_pct` (22 rows)

### Question 9 — Is each order bigger than the last? *(4 marks · Hard)*

**Scenario.** Customer success in **Nyeri** wants to see whether customers are spending more or
less per order through 2026.
**Task.** For customers **living in Nyeri**, list every **completed order placed in 2026**, with
the customer's previous 2026 completed order amount (`total_amount`), the change, and a
direction label `first order / up / down / same`. Order by customer, then order date. Then a
summary query: total rows, distinct customers, first orders, orders bigger than the previous,
orders smaller than the previous.
**Required concept.** `LAG() OVER (PARTITION BY customer_id ORDER BY order_date)`.
**Expected output.** `customer_id, order_id, order_date, total_amount, previous_order_amount, change_amount, direction`

### Question 10 — Year-to-date revenue *(4 marks · Medium)*

**Scenario.** Finance reports cumulative revenue that **restarts every January**.
**Task.** Monthly revenue with a running total that resets each calendar year, and a second running
total that never resets. Use an explicit frame (`ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW`).
**Required concept.** `SUM() OVER (PARTITION BY year ORDER BY month ROWS …)`.
**Expected output.** `year, month, monthly_revenue, running_revenue_ytd, running_revenue_all_time` (22 rows)

---

## Section C — Advanced aggregation with subqueries (20 marks)

### Question 11 — Customer tiers *(4 marks · Medium)*

**Scenario.** The loyalty programme has four tiers by **lifetime revenue**:
Platinum ≥ KES 1,000,000; Gold ≥ 500,000; Silver ≥ 100,000; Bronze below 100,000.
**Task.** For customers with at least one completed order: compute lifetime revenue in an inner
**derived table**, assign the tier with `CASE` in a second derived table around it, then aggregate
per tier. `revenue_share_pct` is the tier's share of **total** completed revenue — compute that total
with a **scalar subquery**. Order from Platinum to Bronze.
**Required concept.** Nested derived tables, `CASE`, scalar subquery.
**Expected output.** `tier, customer_count, min_spent, max_spent, avg_spent, revenue_share_pct` (4 rows)

### Question 12 — What did Mombasa buy in October? *(4 marks · Medium)*

**Scenario.** The Mombasa team wants a one-line shopping list per customer for October 2026.
**Task.** For customers **living in Mombasa** who have at least one **non-cancelled** order placed
in **October 2026** (check this with `EXISTS`), list the distinct products on those October orders
as one string, alphabetical, separated by `'; '`. Order by `product_count` descending, then
customer_id. Second query: the number of customers that qualify.
**Required concept.** `STRING_AGG(DISTINCT … ORDER BY …)`, `EXISTS`.
**Expected output.** `customer_id, full_name, product_count, products_ordered`

### Question 13 — Payment health by method, 2026 *(4 marks · Medium)*

**Scenario.** The payments team suspects one channel fails more often than the others.
**Task.** Put 2026 payments (by `payment_date`) in a CTE. Per `payment_method`: total payments,
successful, failed, pending (each with `COUNT(*) FILTER (WHERE …)`), success rate %, and the total
amount of failed payments. Order by `total_payments` descending.
**Required concept.** `FILTER` clause, CTE.
**Expected output.** `payment_method, total_payments, successful, failed, pending, success_rate_pct, failed_amount` (4 rows)

### Question 14 — Which departments carry the profit? *(4 marks · Medium)*

**Scenario.** The board asks which categories earned **more gross profit than the average
category** in 2025.
**Task.** CTE with 2025 revenue and gross profit per category. Return only the categories whose
gross profit is above the average category gross profit (use a **scalar subquery on the CTE** —
not a hard-coded number). Show the margin and how far above the average each one is, in %.
Order by `gross_profit` descending.
**Required concept.** CTE + scalar subqueries in `SELECT` and `WHERE`.
**Expected output.** `category, revenue, gross_profit, margin_pct, avg_category_gross_profit, pct_above_avg`

### Question 15 — One sales table with subtotals *(4 marks · Hard)*

**Scenario.** Regional heads want 2026 revenue for **Nairobi, Mombasa, Kisumu, Nakuru and Uasin Gishu**
by category, with county subtotals, category subtotals and a grand total — in **one** query.
**Task.** CTE with the 2026 completed order lines for those five **shipping counties**. Aggregate
with `GROUPING SETS ((county, category), (county), (category), ())`. Label each row with
`GROUPING()`: `county x category`, `county total`, `category total`, `grand total`; show
`ALL COUNTIES` / `ALL CATEGORIES` instead of NULL. `order_count` = distinct orders.
**Required concept.** `GROUPING SETS`, `GROUPING()`.
**Expected output.** `grouping_level, county, category, revenue, order_count` (36 rows)

---

## Section D — Views, functions, stored procedures and triggers (25 marks)

All objects go in schema `sokomart`. Use `CREATE OR REPLACE` so your file can be re-run.
After every `CALL`, **run a SELECT that proves what changed** and screenshot it.

### Question 16 — Customer summary view and monthly category materialized view *(5 marks · Medium)*

**Scenario.** Analysts keep rewriting the same customer and category queries.
**Task.**
**(a)** Create the view `sokomart.v_customer_purchase_summary`, built on CTEs, with **one row for
every customer** — including the ones with no completed orders (0 orders, 0 spent, NULL dates).
`days_since_last_order` is counted to **31 October 2026**. Then: the top 10 customers living in
**Kiambu** by `lifetime_spent`; and a query returning the number of rows in the view and the number
of customers with `completed_orders = 0`.
**(b)** Create the materialized view `sokomart.mv_monthly_category_sales`: one row per month and
category for completed orders, with a unique index on `(sales_month, category)`. Show the
**December 2025** rows ordered by revenue.
**Required concept.** `CREATE VIEW` over CTEs + `LEFT JOIN`; `CREATE MATERIALIZED VIEW`.
**Expected output.**
(a) `customer_id, full_name, county, registration_date, completed_orders, lifetime_spent, avg_order_value, first_order_date, last_order_date, days_since_last_order`
(b) `sales_month, category, orders, units_sold, revenue, gross_profit`

### Question 17 — Function: customer spend for a date range *(4 marks · Medium)*

**Scenario.** Customer care needs "how much has this customer spent between these dates?" on demand.
**Task.** Write `sokomart.fn_customer_spend(p_customer_id INTEGER, p_start_date DATE, p_end_date DATE)
RETURNS NUMERIC` — completed revenue for orders placed from `p_start_date` to `p_end_date`
**inclusive of the whole end day**. Return `0` (not NULL) when there is nothing. Raise an exception
when the end date is before the start date. Then:
1. Call it for customer **4000** for: 2025; Jan–Oct 2026; 1 Jan 2025–31 Oct 2026; December 2025; and for customer `-1`.
2. Show that the all-time value equals `lifetime_spent` for customer 4000 in your Q16 view.
3. Use it inside a query: top 5 customers **living in Nairobi** by December 2025 spend.
4. Show the exception for `('2026-02-01', '2026-01-01')`.
**Required concept.** PL/pgSQL function with parameters, validation, `RAISE EXCEPTION`.
**Expected output.** (1) five numbers; (2) `customer_id, lifetime_spent, fn_value, matches`;
(3) `customer_id, full_name, december_2025_spend`; (4) the error message.

### Question 18 — Procedure: change a price and keep its history *(5 marks · Medium)*

**Scenario.** The supplier of **Pwani Golden Cooking Oil 3L (product 71)** has raised prices.
Every price change must be recorded.
**Task.** Write `sokomart.sp_update_product_price(p_product_id INTEGER, p_new_price NUMERIC, p_reason VARCHAR)`.
It must: lock the product row (`SELECT … FOR UPDATE`); raise an exception if the product does not
exist, if the new price is ≤ 0, or if it is **below the product's `cost_price`**; update
`products.unit_price`; insert a row into `product_price_history` (old price, new price, reason);
and insert a row into `audit_logs` (`table_name = 'products'`, `action = 'UPDATE'`, old and new
price as JSONB). Then:
1. Show product 71's price and cost. `CALL` the procedure to set it to **KES 1,099.00**, reason
   `'Supplier price increase - Nov 2026'`. Show the new price, the history row and the audit row.
2. `CALL` it with **KES 500.00** and show it is rejected **and** that no extra history row was written.
**Required concept.** Stored procedure, `FOR UPDATE`, validation, writing to several tables.
**Expected output.** `product_id, product_name, unit_price, cost_price` (before/after);
`price_history_id, product_id, old_price, new_price, change_reason`; `table_name, record_id, action, old_data, new_data`.

### Question 19 — Trigger + procedure: order status changes are always logged *(5 marks · Hard)*

**Scenario.** Disputes keep coming up about who changed an order's status and when.
**Task.**
**(a)** Write a trigger function and the trigger `trg_orders_status_audit` (`AFTER INSERT OR UPDATE
OF order_status ON sokomart.orders FOR EACH ROW`). On insert it writes an `order_status_history`
row with `old_status` NULL; on an update **that actually changes** the status it writes the old and
new status. Both cases also write an `audit_logs` row.
**(b)** Write `sokomart.sp_update_order_status(p_order_id INTEGER, p_new_status VARCHAR)` that allows
only `pending → completed`, `pending → cancelled` and `completed → returned`, and raises an exception
for anything else. When an order becomes `completed` its payment becomes `successful`; when it becomes
`cancelled` an unpaid payment becomes `failed`.
**(c)** Prove it on order **48882** (pending): show order + payment status, `CALL` the procedure to
complete it, show both again, the history row and the audit row. Then run a **plain** `UPDATE` setting it
to `returned` and show that the trigger logged that too. Then run an `UPDATE` that sets
`shipping_county = shipping_county` and show that **no** new history row appeared (still 2).
Finally show the exception for `CALL sokomart.sp_update_order_status(49961, 'completed')` (a cancelled order).
**Required concept.** Trigger function, `TG_OP`, `OLD`/`NEW`, `IS DISTINCT FROM`; procedure with rules.
**Expected output.** `order_id, order_status, payment_status`; `order_id, old_status, new_status`;
`table_name, record_id, action, old_data, new_data`; the error message.

### Question 20 — Procedure: place an order atomically *(6 marks · Hard)*

**Scenario.** The new checkout service will call one database procedure to place an order. Either the
whole order is saved — order, lines, payment, stock — or nothing is.
**Task.** Write
`sokomart.sp_place_order(p_customer_id INTEGER, p_product_ids INTEGER[], p_quantities INTEGER[], p_payment_method VARCHAR, INOUT p_order_id INTEGER DEFAULT NULL)`. It must:
- reject a customer who does not exist or is not `active`, and arrays of different lengths;
- insert the order (`pending`, today, `shipping_county` = the customer's county);
- for each product, **decrease stock with a conditional UPDATE** (`… WHERE stock_quantity >= qty AND
  product_status = 'active'`); if no row was updated, `RAISE EXCEPTION` with the product id, requested
  and available quantity — this undoes everything done so far;
- insert each order line at the product's current price, no discount;
- set `delivery_fee` with the SokoMart rule (`docs/data_dictionary.md`: free from KES 5,000 of items;
  otherwise Nairobi 200, Kiambu/Kajiado/Machakos 250, elsewhere 350) and `total_amount`;
- insert a `pending` payment for the full amount (a transaction reference for every method except cash on delivery);
- return the new `order_id`.
Then:
1. Show products 6, 73, 82 (price, stock). `CALL sokomart.sp_place_order(177, ARRAY[6,73,82], ARRAY[1,2,3], 'M-Pesa', NULL);`
   Show the order (with its items total), its lines, its payment, the new stock, and the status-history row your Q19 trigger wrote.
2. Show the order count and stock for products 6 and 59. `CALL sokomart.sp_place_order(408, ARRAY[6,59], ARRAY[1,2], 'card', NULL);`
   (product 59 has only 1 unit). Show the error, then show the order count and both stock levels **unchanged**.
3. Complete your new order with `sp_update_order_status`, `REFRESH MATERIALIZED VIEW CONCURRENTLY
   sokomart.mv_monthly_category_sales`, and show the November 2026 rows that now exist.
**Required concept.** Atomic stored procedure, arrays, `INOUT`, `RETURNING … INTO`, conditional update as a stock lock, materialized view refresh.
**Expected output.** `order_id, customer_id, order_status, shipping_county, delivery_fee, total_amount, items_total`;
`order_id, product_id, quantity, unit_price, line_total`; `order_id, payment_method, amount, payment_status, has_reference`;
the error message; `sales_month, category, orders, units_sold, revenue, gross_profit`.

---

## Section E — Optimisation and transactions (15 marks)

### Question 21 — Read a query plan *(2 marks · Medium)*

**Scenario.** The Kisumu dashboard query feels slow.
**Task.** Run `EXPLAIN (ANALYZE, BUFFERS)` on this query, then run the query itself:
```sql
SELECT c.customer_id, c.first_name, c.last_name, SUM(i.line_total) AS revenue
FROM sokomart.customers c
JOIN sokomart.orders o      ON o.customer_id = c.customer_id
JOIN sokomart.order_items i ON i.order_id = o.order_id
WHERE c.county = 'Kisumu'
  AND o.order_status = 'completed'
  AND o.order_date >= '2026-09-01' AND o.order_date < '2026-10-01'
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY revenue DESC;
```
In your SQL file, under the plan, add a comment block filling in this table from **your** plan:
`top_node | join_methods_used | scan_on_orders | scan_on_customers | estimated_vs_actual_rows_orders | planning_ms | execution_ms | result_rows`.
**Required concept.** `EXPLAIN ANALYZE`, `BUFFERS`.
**Expected output.** The plan (screenshot) + the filled-in table + the query's row count.

### Question 22 — Prove the indexes help *(3 marks · Hard)*

**Scenario.** You must convince the team lead that `05_indexes.sql` is worth deploying.
**Task.**
**(a)** Drop the indexes (the commented `DROP INDEX` block at the bottom of `05_indexes.sql`) and run
`ANALYZE`. Run `EXPLAIN ANALYZE` on: (1) `SELECT order_id, order_date, total_amount FROM sokomart.orders
WHERE customer_id = 408 ORDER BY order_date;` (2) `SELECT * FROM sokomart.payments WHERE order_id = 25000;`
(3) `SELECT order_id, quantity, line_total FROM sokomart.order_items WHERE product_id = 71;`
**(b)** Run `05_indexes.sql` again, and repeat the three plans.
**(c)** Create a **partial index** `idx_orders_pending_date` on `orders(order_date) WHERE order_status = 'pending'`,
show a plan that uses it for `WHERE order_status = 'pending' AND order_date < '2026-10-25'`, and compare its
size with `idx_orders_order_date` using `pg_relation_size`.
Record a comparison table in a comment: `query | scan_before | execution_ms_before | scan_after | execution_ms_after | rows`.
**Required concept.** Index design, before/after plans, partial index.
**Expected output.** 6 plans + the partial-index plan + `partial_index_size, full_index_size` + the comparison table.

### Question 23 — Transactions you can see *(3 marks · Medium)*

**Scenario.** The merchandising team wants to try out price and stock changes safely.
**Task.**
**(a)** Show the average Beauty price. `BEGIN`; cut every Beauty price by 10% (round to 2 dp); show the
average inside the transaction; `ROLLBACK`; show it is back to the original.
**(b)** Show stock for products 59 and 166. `BEGIN`; add 40 units to product 59 and insert an
`audit_logs` row recording the restock; `SAVEPOINT after_restock`; set product 166's stock to 0 by
mistake; show both; `ROLLBACK TO SAVEPOINT after_restock`; `COMMIT`. Show that 59 kept its +40 and 166 is unchanged.
**(c)** `BEGIN`; add 1 to product 166's stock; then try to set it to **−5** (breaks `chk_products_stock`);
`COMMIT`. Show the error, that `COMMIT` reported `ROLLBACK`, and that product 166's stock is unchanged.
**Required concept.** `BEGIN / COMMIT / ROLLBACK / SAVEPOINT / ROLLBACK TO SAVEPOINT`, aborted transactions.
**Expected output.** before/inside/after values for each part, and the error message in (c).

### Question 24 — Clean up the duplicate payments *(3 marks · Hard)*

**Scenario.** Some settlement files were sent twice (or three times), so `payment_staging` has
duplicate rows. Finance must not double-count them.
**Task.** A duplicate is a row with the same `payment_id, order_id, payment_date, payment_method, amount,
payment_status, transaction_reference` as an earlier row. Keep the **first-loaded** copy (earliest
`loaded_at`, then lowest `staging_id`).
**(a)** Count the duplicated payments, the extra rows to delete and the most copies of one payment.
**(b)** List the first 10 rows that will be deleted, with their copy number (`ROW_NUMBER()`).
**(c)** Show row count and distinct `payment_id` count. In a transaction: delete the extra rows **using
the `ROW_NUMBER()` CTE**; check that rows = distinct payments and that the staged amount equals the sum of
the same payments in `sokomart.payments`; then `COMMIT`.
**(d)** Add a unique index on `payment_staging(payment_id)` and show that re-inserting a payment now fails.
Touch **only** `payment_staging`.
**Required concept.** `ROW_NUMBER()` dedup, `DELETE … USING`, transaction, unique index.
**Expected output.** (a) `duplicated_payments, extra_rows_to_delete, max_copies`;
(b) `staging_id, payment_id, transaction_reference, amount, source_file, loaded_at, copy_no`;
(c) `staging_rows_before, distinct_payments_before` / `staging_rows_after, distinct_payments_after, staged_amount_after, same_payments_in_payments_table`;
(d) the error message.

### Question 25 — Three months in a row *(4 marks · Hard)*

**Scenario.** Retention wants customers who bought (completed orders) in **at least 3 consecutive
calendar months** — the habit the subscription offer is aimed at.
**Task.** Build distinct customer-months in a CTE, find runs of consecutive months (gaps-and-islands:
`month − ROW_NUMBER() months` is constant along a run, or use `LAG`), and for each qualifying customer
return their **longest** run (earliest one if tied). Show the top 10 by `streak_length` (then customer_id),
and a second query with the number of qualifying customers and the longest streak in the data.
**Required concept.** Chained CTEs + window functions (gaps and islands).
**Expected output.** `customer_id, full_name, county, streak_start_month, streak_end_month, streak_length`;
then `customers_with_3plus_streak, longest_streak`.

---

## Marks summary

| Section | Questions | Marks |
|---|---|---|
| Practice drills | D1–D10 | unmarked |
| A — CTEs and subqueries | Q1–Q5 (4 each) | 20 |
| B — Window functions | Q6–Q10 (4 each) | 20 |
| C — Advanced aggregation with subqueries | Q11–Q15 (4 each) | 20 |
| D — Views, functions, procedures, triggers | Q16 (5), Q17 (4), Q18 (5), Q19 (5), Q20 (6) | 25 |
| E — Optimisation and transactions | Q21 (2), Q22 (3), Q23 (3), Q24 (3), Q25 (4) | 15 |
| **Total** | | **100** |

Each question's marks are split roughly: **correct result** (about half), **the required
concept actually used** (a quarter — a right answer without the CTE / subquery / procedure the
question asks for loses these), and **clean, readable, re-runnable SQL with a screenshot** (a quarter).
See `submission_guidelines.md` for what to hand in.
