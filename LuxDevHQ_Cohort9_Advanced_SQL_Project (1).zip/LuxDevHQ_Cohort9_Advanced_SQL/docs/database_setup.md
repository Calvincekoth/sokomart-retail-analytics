# Database setup

You need **PostgreSQL 14 or newer** (tested on PostgreSQL 17) and the `psql` command-line client.
A GUI (DBeaver, pgAdmin, DataGrip) is fine for writing queries, but load the data with `psql`.

Database: `luxdevhq_cohort9_advanced_sql` · Schema: `sokomart`

## 1. Tell psql where your server is (no passwords in files)

Nothing in this project stores a host, user or password. Give them to `psql` as flags
(`-h host -p port -U user`) or set the standard PostgreSQL environment variables once per terminal:

```bash
# macOS / Linux / WSL / Git Bash
export PGHOST=localhost
export PGPORT=5432
export PGUSER=your_postgres_user
# psql will prompt for the password; or put it in ~/.pgpass (chmod 600) - never in the repo
```

```powershell
# Windows PowerShell
$env:PGHOST="localhost"; $env:PGPORT="5432"; $env:PGUSER="your_postgres_user"
```

Check: `psql -d postgres -c "SELECT version();"`

Your user needs permission to create a database (`CREATEDB`). If it does not have it, ask whoever
runs your server to run step 3's first command for you, or use the `postgres` superuser on your own machine.

## 2. Go into the `database/` folder

**This matters.** `04_insert_data.sql` loads the CSVs with `\copy … FROM '../datasets/…'`, a path
relative to where you run psql from.

```bash
cd LuxDevHQ_Cohort9_Advanced_SQL/database
```

## 3. Run the files in order

```bash
psql -d postgres -f 01_create_database.sql                         # on its own: CREATE DATABASE cannot run in a transaction
psql -d luxdevhq_cohort9_advanced_sql -f 02_create_schema.sql
psql -d luxdevhq_cohort9_advanced_sql -f 03_create_tables.sql
psql -d luxdevhq_cohort9_advanced_sql -f 04_insert_data.sql        # about 5 seconds
psql -d luxdevhq_cohort9_advanced_sql -f 05_indexes.sql
psql -d luxdevhq_cohort9_advanced_sql -f 06_validation.sql
```

Inside an interactive `psql` session the same thing is:

```
\i 01_create_database.sql
\c luxdevhq_cohort9_advanced_sql
\i 02_create_schema.sql
\i 03_create_tables.sql
\i 04_insert_data.sql
\i 05_indexes.sql
\i 06_validation.sql
```

`04_insert_data.sql` prints `COPY 5000`, `COPY 300`, `COPY 50000`, `COPY 120000`, `COPY 50000`,
`COPY 2640`. `06_validation.sql` prints 41 checks; **every one must say PASS**, followed by
`ALL CHECKS PASSED`. If one says FAIL, do not start the questions — reset (step 5) and reload.

Then try `psql -d luxdevhq_cohort9_advanced_sql -f ../sample_queries/connection_test.sql`.

## 4. If `\copy` is not an option — the INSERT loader

Some GUI tools (pgAdmin's query tool, DBeaver's SQL editor) cannot run `\copy`. Use
`database/04b_insert_data_inserts.sql` **instead of** `04_insert_data.sql` (after 01–03). It is plain
SQL `INSERT` statements (about 15 MB), needs no CSV files, runs from any folder, and loads exactly the
same rows. It is slower than `\copy` (a few seconds with psql on a laptop; noticeably longer in a GUI).

```bash
psql -d luxdevhq_cohort9_advanced_sql -f 04b_insert_data_inserts.sql
```

Both loaders are written by `scripts/generate_dataset.py` (the INSERT one with `--inserts`). The
generator is deterministic, so if you ever lose a file you can recreate it:

```bash
cd LuxDevHQ_Cohort9_Advanced_SQL
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python3 scripts/generate_dataset.py --inserts           # rewrites datasets/*.csv, 04 and 04b - identical bytes
python3 scripts/generate_dataset.py --sample --inserts  # a small 1,000-order copy in ./sample_build/ for experiments
```

## 5. Reset and start again

```bash
cd LuxDevHQ_Cohort9_Advanced_SQL/database
psql -d luxdevhq_cohort9_advanced_sql -f 07_reset_database.sql
psql -d luxdevhq_cohort9_advanced_sql -f 03_create_tables.sql
psql -d luxdevhq_cohort9_advanced_sql -f 04_insert_data.sql
psql -d luxdevhq_cohort9_advanced_sql -f 05_indexes.sql
psql -d luxdevhq_cohort9_advanced_sql -f 06_validation.sql
```

`07_reset_database.sql` drops **only the schema `sokomart`** in `luxdevhq_cohort9_advanced_sql`
(every table, view, function, procedure and trigger you created there) and recreates it empty. It
refuses to run if you are connected to any other database, and it never drops a database. Use it
whenever Sections D and E have changed data and you want the original numbers back.

To remove the project completely: `psql -d postgres -c "DROP DATABASE luxdevhq_cohort9_advanced_sql;"`

## Running PostgreSQL in Docker

```bash
docker run -d --name sokomart-pg -e POSTGRES_PASSWORD=choose_one -p 5432:5432 postgres:17
export PGHOST=localhost PGPORT=5432 PGUSER=postgres
```

`\copy` reads the CSVs on **your** machine and streams them to the server, so the steps above work
unchanged against Docker. (Server-side `COPY … FROM '/path'` would need the files inside the
container — that is why this project uses `\copy`.)

## Troubleshooting

| Message | Cause and fix |
|---|---|
| `../datasets/customers.csv: No such file or directory` | You are not in the `database/` folder. `cd` into it and run again. |
| `database "luxdevhq_cohort9_advanced_sql" already exists` | It was created before. Use step 5 to reset, or drop it. |
| `CREATE DATABASE cannot run inside a transaction block` | Your GUI wraps scripts in a transaction. Run `01_create_database.sql` with `psql`, or turn on auto-commit. |
| `invalid command \copy` (in a GUI) | Your tool does not support psql meta-commands. Use `04b_insert_data_inserts.sql` (step 4). |
| `relation "sokomart.customers" already exists` | Tables are already there. Use step 5. |
| `permission denied to create database` | Your user lacks `CREATEDB`; see step 1. |
| `duplicate key value violates unique constraint` while loading | A partial earlier load. Use step 5 (the load runs in one transaction, so a failed load leaves nothing behind). |
| Windows: garbled names | Run `chcp 65001` before `psql`, or `SET client_encoding = 'UTF8';`. |
