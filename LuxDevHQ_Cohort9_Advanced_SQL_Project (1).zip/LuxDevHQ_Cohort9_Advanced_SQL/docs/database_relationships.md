# Database relationships

Schema `sokomart` in database `luxdevhq_cohort9_advanced_sql`.

```
                        ┌──────────────────────┐
                        │      customers       │
                        │ PK customer_id       │
                        └──────────┬───────────┘
                                   │ 1
                                   │
                                   │ 0..*   (some customers have no orders)
┌──────────────────────┐   ┌───────┴──────────────┐   1      1 ┌──────────────────────┐
│ order_status_history │*─1│        orders        │────────────│       payments       │
│ FK order_id          │   │ PK order_id          │            │ PK payment_id        │
└──────────────────────┘   │ FK customer_id       │            │ FK order_id          │
                           └───────┬──────────────┘            └──────────────────────┘
                                   │ 1
                                   │
                                   │ 1..6
                           ┌───────┴──────────────┐
                           │     order_items      │
                           │ PK order_item_id     │
                           │ FK order_id          │
                           │ FK product_id        │
                           │ UQ (order_id, product_id)
                           └───────┬──────────────┘
                                   │ 0..*   (some products were never ordered)
                                   │
                                   │ 1
┌───────────────────────┐  ┌───────┴──────────────┐
│ product_price_history │*─1│       products       │
│ FK product_id         │  │ PK product_id        │
└───────────────────────┘  └──────────────────────┘

 audit_logs        - no foreign keys: (table_name, record_id) points at a row in any table
 payment_staging   - no foreign keys on purpose: raw settlement files, may contain duplicates
```

## Relationships

| Parent | Child | Key | Cardinality | Notes |
|---|---|---|---|---|
| customers | orders | `orders.customer_id → customers.customer_id` | 1 : 0..* | Some customers have never ordered. |
| orders | order_items | `order_items.order_id → orders.order_id` (ON DELETE CASCADE) | 1 : 1..6 | Every order has at least one line; a product appears at most once per order. |
| products | order_items | `order_items.product_id → products.product_id` | 1 : 0..* | Some products have never been ordered. |
| orders | payments | `payments.order_id → orders.order_id` (ON DELETE CASCADE) | 1 : 1 in the loaded data | One payment per order. The schema does not forbid more (a retried payment would be a second row). |
| orders | order_status_history | `order_status_history.order_id → orders.order_id` | 1 : 0..* | Empty after loading; filled by the Q19 trigger. |
| products | product_price_history | `product_price_history.product_id → products.product_id` | 1 : 0..* | Empty after loading; filled by the Q18 procedure. |
| (any) | audit_logs | `(table_name, record_id)` — logical only | — | Empty after loading; written by Q18–Q20 and Q23. |
| payments | payment_staging | `payment_staging.payment_id` = `payments.payment_id` — logical only | 1 : 0..* | Some payments were staged more than once (Q24). |

## Rules that tie the tables together

These hold for every row of a fresh load and are checked by `06_validation.sql`:

- `order_items.line_total = ROUND(quantity * unit_price * (1 - discount_percentage / 100), 2)` —
  also enforced by the CHECK constraint `chk_items_line_total`.
- `orders.total_amount = SUM(order_items.line_total) + orders.delivery_fee` for the order.
- `payments.amount = orders.total_amount` for the order's payment.
- A `completed` or `returned` order has a `successful` payment; a `cancelled` order has a `failed`
  payment; a `pending` order has a `pending` (or `failed`) payment.
- `order_items.unit_price` is the price **on the day of the order** — it may differ from today's
  `products.unit_price` (for example after Q18). Revenue always uses `order_items`.
- `orders.order_date` is on or after the customer's `registration_date` and the product's `created_at`.
- `payments.transaction_reference` is unique, and NULL only for cash-on-delivery payments that were
  never collected.

## Typical join paths

```sql
-- revenue by anything about the customer
customers c JOIN orders o ON o.customer_id = c.customer_id
            JOIN order_items i ON i.order_id = o.order_id      -- WHERE o.order_status = 'completed'

-- revenue by anything about the product
order_items i JOIN products p ON p.product_id = i.product_id

-- payment analysis
orders o JOIN payments p ON p.order_id = o.order_id
```

Joining `payments` and `order_items` to `orders` in the same query multiplies payment rows by the
number of lines. Aggregate one side in a CTE or derived table first.
