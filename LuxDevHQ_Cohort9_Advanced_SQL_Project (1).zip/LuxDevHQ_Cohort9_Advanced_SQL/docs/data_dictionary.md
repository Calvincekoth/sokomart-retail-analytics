# Data dictionary — SokoMart Kenya

Database `luxdevhq_cohort9_advanced_sql`, schema `sokomart`. All data is **synthetic**: names are
random combinations, emails use `@example.co.ke` / `@sokomart-demo.ke`, and every phone number
has the form `07XX 555 XXX` (the `555` block marks it as fake).

All money columns are `NUMERIC(12,2)`, in Kenya shillings (KES). Never `FLOAT`.

## The revenue rule (read this first)

| Measure | Definition |
|---|---|
| **Revenue** | `SUM(order_items.line_total)` for orders with `order_status = 'completed'` |
| **Cost** | `SUM(order_items.quantity * products.cost_price)` for the same order lines |
| **Gross profit** | Revenue − cost |
| **Margin %** | 100 × gross profit ÷ revenue |
| **Order value** | `orders.total_amount` (= items + delivery fee) — what the customer paid |

Not revenue: delivery fees (they pay the courier), `pending` orders (not delivered yet), `cancelled`
orders (never paid), `returned` orders (refunded). `payments.amount` is used for **payment analysis**
(success rates, failed amounts, reconciliation) — not as revenue.

## customers — 5,000 rows

| Column | Type | Null | Description |
|---|---|---|---|
| customer_id | INTEGER (identity) | PK | Customer number |
| first_name | VARCHAR(60) | NOT NULL | |
| last_name | VARCHAR(60) | NOT NULL | |
| email | VARCHAR(150) | NOT NULL, UNIQUE | Synthetic, `@example.co.ke` or `@sokomart-demo.ke` |
| phone_number | VARCHAR(20) | **NULL allowed** | `07XX 555 XXX`; NULL for ~3% who never gave one |
| county | VARCHAR(40) | NOT NULL | Where the customer lives (14 counties; Nairobi ~34%) |
| registration_date | DATE | NOT NULL, default today | Late 2023 … 31 Oct 2026; always on or before the customer's first order |
| customer_status | VARCHAR(12) | NOT NULL, default `active` | `active`, `inactive`, `suspended` |

## products — 300 rows

| Column | Type | Null | Description |
|---|---|---|---|
| product_id | INTEGER (identity) | PK | |
| product_name | VARCHAR(150) | NOT NULL, UNIQUE | Brand + item + variant, e.g. `Ramtons Microwave Oven 25L` |
| category | VARCHAR(40) | NOT NULL | `Electronics` (70), `Groceries` (80), `Fashion` (60), `Home Appliances` (45), `Beauty` (45) |
| brand | VARCHAR(60) | **NULL allowed** | NULL for unbranded produce (eggs, beans, tomatoes…) |
| unit_price | NUMERIC(12,2) | NOT NULL, > 0 | Current selling price |
| cost_price | NUMERIC(12,2) | NOT NULL, ≥ 0 | Current buying price. Two groceries are loss leaders (cost > price) |
| stock_quantity | INTEGER | NOT NULL, ≥ 0, default 0 | Units on hand |
| created_at | TIMESTAMP | NOT NULL | When the product was listed; new arrivals in Oct 2026 |
| product_status | VARCHAR(15) | NOT NULL, default `active` | `active`, `discontinued`, `out_of_stock` |

Typical margins: Groceries 6–18%, Electronics 8–22%, Home Appliances 12–28%, Beauty 30–55%, Fashion 35–60%.

## orders — 50,000 rows

| Column | Type | Null | Description |
|---|---|---|---|
| order_id | INTEGER (identity) | PK | Increases with `order_date` in the loaded data |
| customer_id | INTEGER | NOT NULL, FK → customers | |
| order_date | TIMESTAMP | NOT NULL, default now | 2025-01-01 … 2026-10-31 |
| order_status | VARCHAR(12) | NOT NULL, default `pending` | `completed` (42,168), `cancelled` (4,446), `returned` (2,969), `pending` (417, all from 18 Oct 2026 on) |
| shipping_county | VARCHAR(40) | NOT NULL | Delivery county; the customer's own county for about 90% of orders |
| delivery_fee | NUMERIC(12,2) | NOT NULL, ≥ 0 | See the delivery rule below |
| total_amount | NUMERIC(12,2) | NOT NULL, ≥ 0 | `SUM(order_items.line_total) + delivery_fee` |

**Delivery rule:** free when the items subtotal is KES 5,000 or more; otherwise Nairobi KES 200,
Kiambu / Kajiado / Machakos KES 250, every other county KES 350 (by `shipping_county`).

**Seasonality built into the data:** December is the busiest month, then November (Black Friday,
with deeper discounts), then the back-to-school months January, May and August. February and June
are quiet. Volume grows slowly over the 22 months.

## order_items — 120,000 rows

| Column | Type | Null | Description |
|---|---|---|---|
| order_item_id | INTEGER (identity) | PK | |
| order_id | INTEGER | NOT NULL, FK → orders (cascade) | |
| product_id | INTEGER | NOT NULL, FK → products | UNIQUE together with order_id |
| quantity | INTEGER | NOT NULL, > 0 | |
| unit_price | NUMERIC(12,2) | NOT NULL, > 0 | Price charged on the order date |
| discount_percentage | NUMERIC(5,2) | NOT NULL, 0–100, default 0 | 0, 5, 10, 15, 20 (25 in November) |
| line_total | NUMERIC(12,2) | NOT NULL | `ROUND(quantity * unit_price * (1 - discount_percentage/100), 2)` — CHECK-enforced |

## payments — 50,000 rows

| Column | Type | Null | Description |
|---|---|---|---|
| payment_id | INTEGER (identity) | PK | Equal to order_id in the loaded data (one payment per order) |
| order_id | INTEGER | NOT NULL, FK → orders (cascade) | |
| payment_date | TIMESTAMP | NOT NULL | Minutes after the order (M-Pesa, card), hours (bank transfer), days (cash on delivery) |
| payment_method | VARCHAR(20) | NOT NULL | `M-Pesa` (~62%), `card`, `bank transfer`, `cash on delivery` |
| amount | NUMERIC(12,2) | NOT NULL, > 0 | = the order's `total_amount` |
| payment_status | VARCHAR(12) | NOT NULL, default `pending` | `successful`, `failed`, `pending` |
| transaction_reference | VARCHAR(30) | **NULL allowed**, UNIQUE | Synthetic, e.g. `MPX2510ABCD1234`; NULL only for uncollected cash on delivery |

## payment_staging — 2,640 rows (Question 24)

Raw settlement files before cleaning. Some files were re-sent (`…_resend1.csv`, `…_resend2.csv`),
so some payments appear two or three times. No foreign keys and no uniqueness on the payment columns —
on purpose.

| Column | Type | Description |
|---|---|---|
| staging_id | INTEGER (identity) PK | Load order |
| payment_id, order_id, payment_date, payment_method, amount, payment_status, transaction_reference | as in `payments` | Copied from the provider's file |
| source_file | VARCHAR(80) | e.g. `settlement_2026-03-14.csv`, `settlement_2026-03-14_resend1.csv` |
| loaded_at | TIMESTAMP | When the row was loaded |

## Supporting tables (empty after loading)

**product_price_history** — written by `sp_update_product_price` (Q18): `price_history_id` PK,
`product_id` FK, `old_price`, `new_price`, `change_reason`, `changed_by` (default `CURRENT_USER`), `changed_at` (default now).

**order_status_history** — written by the order-status trigger (Q19): `status_history_id` PK,
`order_id` FK, `old_status` (NULL for a brand-new order), `new_status`, `changed_by`, `changed_at`.

**audit_logs** — general audit trail: `audit_id` PK, `table_name`, `record_id`, `action`
(`INSERT`/`UPDATE`/`DELETE`), `old_data` JSONB, `new_data` JSONB, `changed_by`, `changed_at`.

## Counties

Nairobi, Kiambu, Mombasa, Nakuru, Kisumu, Uasin Gishu (Eldoret), Machakos, Kajiado, Nyeri, Kericho,
Kakamega, Meru, Kilifi, Embu.
