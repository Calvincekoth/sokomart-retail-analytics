#!/usr/bin/env python3
"""
SokoMart Kenya - synthetic dataset generator
LuxDevHQ Cohort 9 - Advanced SQL practical project

Every person, email, phone number and transaction reference produced here is
synthetic. Names come from Faker's en_KE locale and are combined at random, so
they do not describe real people. Emails use the demo domains
@example.co.ke and @sokomart-demo.ke. Phone numbers all have the form
07XX 555 XXX: the "555" middle block marks them as fake.

What it writes (relative to --output-dir):
    datasets/customers.csv, products.csv, orders.csv, order_items.csv,
             payments.csv, payment_staging.csv
    database/04_insert_data.sql            (\\copy loader, always written)
    database/04b_insert_data_inserts.sql   (plain INSERT loader, only with --inserts)

Usage (from the package root):
    python3 scripts/generate_dataset.py                 # full dataset (225,300 core rows)
    python3 scripts/generate_dataset.py --sample        # small dataset in ./sample_build/
    python3 scripts/generate_dataset.py --inserts       # also write the INSERT-based loader
    python3 scripts/generate_dataset.py --customers 1000 --orders 8000 --order-items 20000 ...

The generator is deterministic: the same --seed and counts give byte-identical files.
Rows are written to disk one at a time (csv.writer / file.write); the SQL file is
never built as one big string.
"""

import argparse
import csv
import os
import random
import sys
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

try:
    from faker import Faker
except ImportError:  # pragma: no cover
    sys.exit("Faker is not installed. Run: pip install -r requirements.txt")

CENT = Decimal("0.01")

# ---------------------------------------------------------------------------
# Business rules shared with the SQL side (keep in step with docs/data_dictionary.md
# and with sokomart.sp_place_order in the instructor solutions).
# ---------------------------------------------------------------------------
FREE_DELIVERY_THRESHOLD = Decimal("5000.00")       # items subtotal at or above this ships free
DELIVERY_FEES = {"Nairobi": Decimal("200.00"),
                 "Kiambu": Decimal("250.00"), "Kajiado": Decimal("250.00"),
                 "Machakos": Decimal("250.00")}
DEFAULT_DELIVERY_FEE = Decimal("350.00")             # every other county

DATA_START = datetime(2025, 1, 1)
DATA_END = datetime(2026, 10, 31, 23, 59, 59)

# County -> share of customers. Nairobi dominates, as it does for real Kenyan e-commerce.
COUNTIES = [
    ("Nairobi", 34), ("Kiambu", 12), ("Mombasa", 10), ("Nakuru", 9), ("Kisumu", 7),
    ("Uasin Gishu", 6), ("Machakos", 5), ("Kajiado", 4), ("Nyeri", 3), ("Kericho", 2.5),
    ("Kakamega", 2.5), ("Meru", 2), ("Kilifi", 1.5), ("Embu", 1.5),
]
# County "spend multiplier": how often a customer from the county orders.
COUNTY_ACTIVITY = {"Nairobi": 1.35, "Kiambu": 1.15, "Mombasa": 1.1, "Nakuru": 1.0,
                   "Kisumu": 0.95, "Uasin Gishu": 0.95, "Machakos": 0.85, "Kajiado": 1.05,
                   "Nyeri": 0.9, "Kericho": 0.75, "Kakamega": 0.7, "Meru": 0.8,
                   "Kilifi": 0.7, "Embu": 0.75}

CATEGORIES = ["Electronics", "Groceries", "Fashion", "Home Appliances", "Beauty"]
CATEGORY_SHARE = {"Electronics": 70, "Groceries": 80, "Fashion": 60,
                  "Home Appliances": 45, "Beauty": 45}          # products per 300
CATEGORY_MARGIN = {"Electronics": (0.08, 0.22), "Groceries": (0.06, 0.18),
                   "Fashion": (0.35, 0.60), "Home Appliances": (0.12, 0.28),
                   "Beauty": (0.30, 0.55)}
# How often a line item comes from each category, by month of year.
CATEGORY_PICK = {"Electronics": 12, "Groceries": 42, "Fashion": 19,
                 "Home Appliances": 9, "Beauty": 18}
MONTH_CATEGORY_BOOST = {
    1: {"Fashion": 1.5, "Electronics": 1.3},          # back to school (term 1)
    5: {"Fashion": 1.3},                              # term 2
    8: {"Fashion": 1.4, "Electronics": 1.3},          # term 3 / back to school
    11: {"Electronics": 1.6, "Home Appliances": 1.5}, # Black Friday
    12: {"Electronics": 1.5, "Groceries": 1.2, "Fashion": 1.3, "Beauty": 1.3},  # festive
}
# Seasonality of order volume by month of year.
MONTH_VOLUME = {1: 1.25, 2: 0.85, 3: 0.9, 4: 1.0, 5: 1.1, 6: 0.88, 7: 0.92,
                8: 1.18, 9: 1.0, 10: 1.02, 11: 1.35, 12: 1.65}

QTY_RANGE = {"Electronics": (1, 2), "Groceries": (1, 6), "Fashion": (1, 3),
             "Home Appliances": (1, 1), "Beauty": (1, 4)}

# (item, [brands or None], low, high, [variants])
CATALOGUE = {
    "Electronics": [
        ("Smartphone", ["Samsung|Galaxy", "Tecno|Spark", "Tecno|Camon", "Infinix|Hot",
                        "Infinix|Note", "Xiaomi|Redmi", "Oppo|Reno"], 11000, 65000,
         ["64GB", "128GB", "256GB"]),
        ("Laptop", ["HP", "Lenovo", "Dell", "Asus"], 38000, 145000,
         ["Core i3 8GB", "Core i5 8GB", "Core i5 16GB", "Ryzen 5 16GB"]),
        ("Smart TV", ["Hisense", "TCL", "Samsung", "LG", "Vitron"], 17000, 120000,
         ['32"', '43"', '55"', '65"']),
        ("Wireless Earbuds", ["Oraimo", "JBL", "Samsung", "Anker"], 1800, 14000, ["Lite", "Pro"]),
        ("Power Bank", ["Oraimo", "Anker", "Xiaomi"], 1500, 6500, ["10000mAh", "20000mAh", "30000mAh"]),
        ("Bluetooth Speaker", ["JBL", "Sony", "Oraimo"], 2500, 32000, ["Mini", "Go", "Max"]),
        ("Smartwatch", ["Oraimo", "Samsung", "Xiaomi", "Amazfit"], 3500, 38000, ["Classic", "Sport"]),
        ("Tablet", ["Samsung|Galaxy Tab", "Lenovo|Tab", "Xiaomi|Pad"], 15000, 70000, ["64GB", "128GB"]),
        ("WiFi Router", ["TP-Link", "Huawei", "Tenda"], 2500, 15000, ["Dual Band", "Mesh"]),
    ],
    "Groceries": [
        ("Maize Flour", ["Mlima Bora", "Shamba Gold", "Savanna"], 160, 260, ["2kg"]),
        ("Wheat Flour", ["Mlima Bora", "Savanna", "Pwani Mills"], 170, 280, ["2kg"]),
        ("Pishori Rice", ["Mwea Fields", "Savanna"], 900, 1600, ["2kg", "5kg"]),
        ("Brown Sugar", ["Nzoia Sweet", "Kabarak Valley"], 190, 450, ["1kg", "2kg"]),
        ("Cooking Oil", ["Pwani Golden", "Savanna", "Fresh Fry"], 380, 1450, ["1L", "3L", "5L"]),
        ("Fresh Milk", ["Kilele Dairy", "Mlima Dairy"], 60, 140, ["500ml", "1L"]),
        ("Tea Leaves", ["Kericho Highlands", "Nyayo Gold"], 160, 650, ["250g", "500g", "1kg"]),
        ("Ground Coffee", ["Nyeri Hills", "Kilele"], 450, 1300, ["250g", "500g"]),
        ("Eggs Tray", [None], 420, 620, ["30 pcs"]),
        ("Spaghetti", ["Pwani Mills", "Savanna"], 110, 260, ["500g", "1kg"]),
        ("Sliced Bread", ["Mkate Bora"], 60, 95, ["400g", "600g"]),
        ("Table Salt", ["Pwani Fresh"], 30, 70, ["500g", "1kg"]),
        ("Rosecoco Beans", [None], 180, 320, ["1kg"]),
        ("Green Grams (Ndengu)", [None], 190, 340, ["1kg"]),
        ("Mango Juice", ["Tropical Kenya", "Pwani Fresh"], 160, 380, ["1L", "2L"]),
        ("Pure Honey", ["Baringo Gold", "Kilele"], 450, 980, ["500g", "1kg"]),
        ("Peanut Butter", ["Nutty Kenya"], 280, 620, ["400g", "800g"]),
        ("Margarine", ["Golden Spread"], 180, 520, ["500g", "1kg"]),
        ("Bananas", [None], 120, 260, ["1 bunch"]),
        ("Tomatoes", [None], 90, 220, ["1kg"]),
    ],
    "Fashion": [
        ("Men's Shirt", ["Mitumba Smart", "Nairobi Tailors", "Urban Kenya"], 900, 4500, ["Slim Fit", "Regular Fit"]),
        ("Women's Dress", ["Kitenge House", "Urban Kenya", "Ankara Lane"], 1200, 7500, ["Midi", "Maxi"]),
        ("Kitenge Shirt", ["Kitenge House", "Ankara Lane"], 1200, 4200, ["Short Sleeve", "Long Sleeve"]),
        ("Sneakers", ["Bata", "Stride KE", "Urban Kenya"], 1800, 12500, ["Canvas", "Running"]),
        ("School Shoes", ["Bata", "Stride KE"], 1300, 3800, ["Boys", "Girls"]),
        ("Jeans", ["Urban Kenya", "Denim Co KE"], 1500, 5500, ["Straight", "Skinny"]),
        ("Handbag", ["Maasai Leather", "Ankara Lane"], 1500, 9500, ["Tote", "Crossbody"]),
        ("Maasai Shuka", ["Maasai Leather"], 700, 2200, ["Red Check", "Blue Check"]),
        ("School Uniform Set", ["Nairobi Tailors"], 1800, 4500, ["Primary", "Secondary"]),
        ("Hoodie", ["Urban Kenya", "Denim Co KE"], 1500, 4500, ["Pullover", "Zip-up"]),
    ],
    "Home Appliances": [
        ("Refrigerator", ["Hisense", "LG", "Ramtons", "Samsung"], 28000, 115000, ["Single Door", "Double Door"]),
        ("Microwave Oven", ["Ramtons", "Hisense", "Samsung"], 8500, 22000, ["20L", "25L"]),
        ("Gas Cooker", ["Ramtons", "Von", "Mika"], 15000, 65000, ["2 Burner", "4 Burner"]),
        ("Electric Kettle", ["Ramtons", "Mika", "Philips"], 1500, 4500, ["1.7L", "2L"]),
        ("Blender", ["Ramtons", "Philips", "Mika"], 3200, 12500, ["1.5L", "2L"]),
        ("Washing Machine", ["LG", "Hisense", "Samsung"], 32000, 95000, ["7kg", "9kg"]),
        ("Water Dispenser", ["Ramtons", "Mika", "Von"], 7500, 26000, ["Hot & Cold", "Hot & Normal"]),
        ("Iron Box", ["Philips", "Ramtons", "Sayona"], 1500, 6000, ["Dry", "Steam"]),
        ("Standing Fan", ["Ramtons", "Mika", "Sayona"], 2500, 7500, ['16"', '18"']),
    ],
    "Beauty": [
        ("Body Lotion", ["Nivea", "Shea Kenya", "Bella Naturals"], 250, 1600, ["200ml", "400ml"]),
        ("Hair Relaxer", ["Bella Naturals", "Afro Glow"], 350, 1200, ["Regular", "Super"]),
        ("Shea Butter", ["Shea Kenya", "Bella Naturals"], 400, 1800, ["250g", "500g"]),
        ("Perfume", ["Savanna Scents", "Nairobi Musk"], 1500, 9500, ["50ml", "100ml"]),
        ("Lipstick", ["Afro Glow", "Bella Naturals"], 350, 2200, ["Matte", "Gloss"]),
        ("Hair Braids", ["Afro Glow", "Darling Lane"], 250, 1800, ["Short", "Long"]),
        ("Face Wash", ["Bella Naturals", "Nivea"], 350, 1600, ["150ml", "250ml"]),
        ("Petroleum Jelly", ["Pure Glow", "Shea Kenya"], 120, 480, ["100ml", "250ml"]),
        ("Beard Oil", ["Nairobi Musk"], 600, 2200, ["30ml", "50ml"]),
    ],
}

PACKS = ["Value Pack", "Twin Pack", "Family Pack", "Gift Set", "Mega Pack", "Starter Kit"]
ORDER_STATUSES = ("completed", "pending", "cancelled", "returned")
PAYMENT_METHODS = [("M-Pesa", 62), ("card", 18), ("bank transfer", 8), ("cash on delivery", 12)]


def money(x):
    return Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP)


def line_total(qty, price, disc):
    # Same expression the database checks:
    # round(quantity * unit_price * (1 - discount_percentage / 100), 2), half away from zero.
    return (Decimal(qty) * price * (Decimal(1) - disc / Decimal(100))).quantize(CENT, rounding=ROUND_HALF_UP)


def delivery_fee(county, subtotal):
    if subtotal >= FREE_DELIVERY_THRESHOLD:
        return Decimal("0.00")
    return DELIVERY_FEES.get(county, DEFAULT_DELIVERY_FEE)


def nice_price(rng, low, high):
    p = rng.uniform(low, high)
    step = 50 if p >= 5000 else (10 if p >= 500 else 5)
    return money(max(step, round(p / step) * step) - (1 if p >= 500 and rng.random() < 0.5 else 0))


def ts(d):
    return d.strftime("%Y-%m-%d %H:%M:%S")


def weighted(rng, pairs):
    names = [p[0] for p in pairs]
    weights = [p[1] for p in pairs]
    return rng.choices(names, weights=weights, k=1)[0]


def months_between(start, end):
    out = []
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        out.append((y, m))
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def days_in_month(y, m):
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    return (nxt - date(y, m, 1)).days


# ---------------------------------------------------------------------------
def build(args):
    rng = random.Random(args.seed)
    fake = Faker("en_KE")
    fake.seed_instance(args.seed)

    n_cust, n_prod, n_ord, n_items = args.customers, args.products, args.orders, args.order_items
    if n_items < n_ord:
        sys.exit("--order-items must be >= --orders (every order has at least one item)")
    if n_items > n_ord * 6:
        sys.exit("--order-items must be <= 6 x --orders (an order has at most six lines)")

    # ---------------- products ----------------
    products = []
    seen = set()
    total_share = sum(CATEGORY_SHARE.values())
    per_cat = {c: max(3, round(n_prod * CATEGORY_SHARE[c] / total_share)) for c in CATEGORIES}
    per_cat["Groceries"] += n_prod - sum(per_cat.values())       # absorb rounding
    pid = 0
    for cat in CATEGORIES:
        made, guard = 0, 0
        while made < per_cat[cat]:
            guard += 1
            item, brands, low, high, variants = rng.choice(CATALOGUE[cat])
            label = rng.choice(brands)            # "Samsung|Galaxy" -> brand Samsung, shown "Samsung Galaxy"
            brand = label.split("|")[0] if label else None
            vi = rng.randrange(len(variants))
            variant = variants[vi]
            name = f"{label.replace('|', ' ') + ' ' if label else ''}{item} {variant}"
            if name in seen:
                if guard < 20000:
                    continue
                # Every brand/item/variant combination is taken: fall back to a pack
                # size. Deterministic (no rng call) so the rest of the data is unchanged.
                for pack in PACKS:
                    if f"{name} - {pack}" not in seen:
                        name = f"{name} - {pack}"
                        break
                else:
                    name = f"{name} - Edition {made}"
            seen.add(name)
            pid += 1
            # Variants are listed cheapest first (64GB < 128GB, 32" < 55"), so each
            # variant gets its own slice of the item's price range.
            band = (high - low) / len(variants)
            price = nice_price(rng, low + band * vi, low + band * (vi + 1))
            lo, hi = CATEGORY_MARGIN[cat]
            margin = Decimal(str(round(rng.uniform(lo, hi), 4)))
            if cat == "Groceries" and rng.random() < 0.05:
                margin = Decimal("-0.03")                         # loss leader: sold below cost
            cost = money(price * (Decimal(1) - margin))
            products.append({
                "product_id": pid, "product_name": name, "category": cat,
                "brand": brand, "unit_price": price, "cost_price": cost,
                "stock_quantity": rng.randint(15, 600), "created_at": None,
                "product_status": "active"})
            made += 1

    # Products that never sell: new arrivals (created Oct 2026), discontinued lines,
    # and out-of-stock lines. About 6 % of the catalogue.
    n_unsold = max(3, round(n_prod * 0.06))
    unsold = rng.sample(range(n_prod), n_unsold)
    unsold_ids = set()
    for i, idx in enumerate(unsold):
        p = products[idx]
        unsold_ids.add(p["product_id"])
        kind = i % 3
        if kind == 0:
            p["product_status"] = "active"
            p["created_at"] = datetime(2026, 10, rng.randint(15, 30), rng.randint(8, 17), rng.randint(0, 59))
        elif kind == 1:
            p["product_status"] = "discontinued"
            p["stock_quantity"] = 0
        else:
            p["product_status"] = "out_of_stock"
            p["stock_quantity"] = 0
    for p in products:
        if p["created_at"] is None:
            p["created_at"] = datetime(2024, 1, 1) + timedelta(minutes=rng.randint(0, 365 * 24 * 60 - 1))
    # A few sellable lines are low on stock or sold out (useful for sp_place_order).
    sellable = [p for p in products if p["product_id"] not in unsold_ids]
    for p in rng.sample(sellable, max(2, n_prod // 30)):
        p["stock_quantity"] = rng.randint(0, 4)
        if p["stock_quantity"] == 0:
            p["product_status"] = "out_of_stock"

    by_cat = {c: [p for p in sellable if p["category"] == c] for c in CATEGORIES}
    prod_pop = {p["product_id"]: rng.lognormvariate(0, 0.8) for p in sellable}

    # ---------------- customers ----------------
    customers = []
    email_seen = set()
    for cid in range(1, n_cust + 1):
        first, last = fake.first_name(), fake.last_name()
        base = f"{first}.{last}".lower().replace(" ", "").replace("'", "")
        domain = "example.co.ke" if cid % 3 else "sokomart-demo.ke"
        email = f"{base}{cid}@{domain}"
        assert email not in email_seen
        email_seen.add(email)
        phone = None if rng.random() < 0.03 else f"07{rng.randint(0, 99):02d} 555 {rng.randint(0, 999):03d}"
        status = weighted(rng, [("active", 88), ("inactive", 10), ("suspended", 2)])
        customers.append({"customer_id": cid, "first_name": first, "last_name": last,
                          "email": email, "phone_number": phone,
                          "county": weighted(rng, COUNTIES), "registration_date": None,
                          "customer_status": status})

    # ~8 % of customers never buy.
    n_never = max(2, round(n_cust * 0.08))
    never = set(rng.sample(range(1, n_cust + 1), n_never))
    buyers = [c for c in customers if c["customer_id"] not in never]
    for c in customers:
        if c["customer_id"] in never:
            c["customer_status"] = weighted(rng, [("active", 80), ("inactive", 20)])
    cust_weight = [rng.paretovariate(1.6) * COUNTY_ACTIVITY[c["county"]] for c in buyers]
    cust_weight = [min(w, 25.0) for w in cust_weight]  # cap whales so nobody has 1,000 orders

    # ---------------- orders ----------------
    months = months_between(DATA_START, DATA_END)
    month_w = [MONTH_VOLUME[m] * (1 + 0.018 * i) for i, (y, m) in enumerate(months)]
    raw = []
    for _ in range(n_ord):
        y, m = rng.choices(months, weights=month_w, k=1)[0]
        d = datetime(y, m, rng.randint(1, days_in_month(y, m)),
                     rng.choices(range(24), weights=[1, 1, 1, 1, 1, 2, 4, 6, 8, 9, 9, 9, 10, 9, 8, 8, 8, 9, 10, 10, 9, 7, 4, 2])[0],
                     rng.randint(0, 59), rng.randint(0, 59))
        c = rng.choices(buyers, weights=cust_weight, k=1)[0]
        raw.append((d, c["customer_id"]))
    raw.sort()
    # Guarantee every buyer has at least one order (swap in for a random order).
    have = {cid for _, cid in raw}
    missing = [c["customer_id"] for c in buyers if c["customer_id"] not in have]
    counts = {}
    for _, cid in raw:
        counts[cid] = counts.get(cid, 0) + 1
    i = 0
    for cid in missing:
        while True:
            j = rng.randrange(len(raw))
            if counts[raw[j][1]] > 2:
                counts[raw[j][1]] -= 1
                raw[j] = (raw[j][0], cid)
                counts[cid] = 1
                break
        i += 1

    cust_by_id = {c["customer_id"]: c for c in customers}
    orders = []
    first_order = {}
    for oid, (d, cid) in enumerate(raw, start=1):
        c = cust_by_id[cid]
        ship = c["county"] if rng.random() < 0.88 else weighted(rng, COUNTIES)
        recent = d >= datetime(2026, 10, 18)
        if recent and rng.random() < 0.40:
            st = "pending"
        else:
            # Older orders have all been resolved one way or another; only the
            # last two weeks of October 2026 still have orders awaiting payment/delivery.
            st = weighted(rng, [("completed", 85), ("cancelled", 9), ("returned", 6)])
        orders.append({"order_id": oid, "customer_id": cid, "order_date": d, "order_status": st,
                       "shipping_county": ship, "delivery_fee": None, "total_amount": None})
        first_order[cid] = min(first_order.get(cid, d), d)

    for c in customers:
        if c["customer_id"] in first_order:
            fo = first_order[c["customer_id"]].date()
            reg = fo - timedelta(days=rng.randint(0, 420))
            c["registration_date"] = max(reg, date(2023, 1, 1))
        else:
            c["registration_date"] = date(2024, 1, 1) + timedelta(days=rng.randint(0, (date(2026, 10, 31) - date(2024, 1, 1)).days))

    # ---------------- order items ----------------
    lines_per = [1] * n_ord
    extra = n_items - n_ord
    while extra:
        j = rng.randrange(n_ord)
        if lines_per[j] < 6:
            lines_per[j] += 1
            extra -= 1

    items = []
    iid = 0
    for o, k in zip(orders, lines_per):
        boost = MONTH_CATEGORY_BOOST.get(o["order_date"].month, {})
        cw = [(c, CATEGORY_PICK[c] * boost.get(c, 1.0)) for c in CATEGORIES]
        chosen = set()
        subtotal = Decimal("0.00")
        while len(chosen) < k:
            cat = weighted(rng, cw)
            pool = by_cat[cat]
            p = rng.choices(pool, weights=[prod_pop[x["product_id"]] for x in pool], k=1)[0]
            if p["product_id"] in chosen:
                continue
            chosen.add(p["product_id"])
            qlo, qhi = QTY_RANGE[cat]
            qty = rng.randint(qlo, qhi) if rng.random() < 0.6 else qlo
            disc_pairs = [(0, 65), (5, 15), (10, 12), (15, 5), (20, 3)]
            if o["order_date"].month == 11:
                disc_pairs = [(0, 35), (5, 15), (10, 20), (15, 15), (20, 10), (25, 5)]
            disc = money(weighted(rng, disc_pairs))
            lt = line_total(qty, p["unit_price"], disc)
            iid += 1
            items.append({"order_item_id": iid, "order_id": o["order_id"], "product_id": p["product_id"],
                          "quantity": qty, "unit_price": p["unit_price"],
                          "discount_percentage": disc, "line_total": lt})
            subtotal += lt
        o["delivery_fee"] = delivery_fee(o["shipping_county"], subtotal)
        o["total_amount"] = subtotal + o["delivery_fee"]

    # ---------------- payments ----------------
    payments = []
    used_refs = set()

    def new_ref(method, d):
        prefix = {"M-Pesa": "MPX", "card": "CRD", "bank transfer": "BNK", "cash on delivery": "COD"}[method]
        while True:
            ref = f"{prefix}{d:%y%m}" + fake.bothify("????####", letters="ABCDEFGHJKLMNPQRSTUVWXYZ")
            if ref not in used_refs:
                used_refs.add(ref)
                return ref

    for o in orders:
        method = weighted(rng, PAYMENT_METHODS)
        st = o["order_status"]
        if st in ("completed", "returned"):
            pst = "successful"
        elif st == "cancelled":
            pst = "failed"
        else:
            pst = "pending" if rng.random() < 0.8 else "failed"
        d = o["order_date"]
        if method in ("M-Pesa", "card"):
            pd = d + timedelta(minutes=rng.randint(1, 45))
        elif method == "bank transfer":
            pd = d + timedelta(hours=rng.randint(2, 40))
        else:
            pd = d + timedelta(days=rng.randint(1, 4), hours=rng.randint(0, 8))
        if pd > DATA_END:
            pd = d + (DATA_END - d) / 2
        ref = None if (method == "cash on delivery" and pst != "successful") else new_ref(method, pd)
        payments.append({"payment_id": o["order_id"], "order_id": o["order_id"],
                         "payment_date": pd.replace(microsecond=0), "payment_method": method,
                         "amount": o["total_amount"], "payment_status": pst,
                         "transaction_reference": ref})

    # ---------------- payment_staging (dedup exercise) ----------------
    n_stage = max(20, round(len(payments) * 0.048))
    stage_src = sorted(rng.sample(payments, n_stage), key=lambda p: p["payment_date"])
    n_dup2 = max(2, n_stage // 15)       # duplicated once  (2 copies)
    n_dup3 = max(1, n_stage // 60)       # duplicated twice (3 copies)
    dup = rng.sample(stage_src, n_dup2 + n_dup3)
    staged = []
    for p in stage_src:
        staged.append((p, f"settlement_{p['payment_date']:%Y-%m-%d}.csv",
                       p["payment_date"] + timedelta(hours=rng.randint(1, 20))))
    for k, p in enumerate(dup):
        copies = 1 if k < n_dup2 else 2
        for c in range(copies):
            staged.append((p, f"settlement_{p['payment_date']:%Y-%m-%d}_resend{c + 1}.csv",
                           p["payment_date"] + timedelta(days=1 + c, hours=rng.randint(1, 20))))
    staged.sort(key=lambda t: t[2])
    staging = []
    for sid, (p, src, loaded) in enumerate(staged, start=1):
        staging.append({"staging_id": sid, **{k: p[k] for k in ("payment_id", "order_id", "payment_date",
                        "payment_method", "amount", "payment_status", "transaction_reference")},
                        "source_file": src, "loaded_at": loaded.replace(microsecond=0)})

    return customers, products, orders, items, payments, staging


# ---------------------------------------------------------------------------
def validate(customers, products, orders, items, payments, staging):
    """Fail loudly before a single byte is written."""
    errs = []
    cids = {c["customer_id"] for c in customers}
    pids = {p["product_id"] for p in products}
    oids = {o["order_id"] for o in orders}
    reg = {c["customer_id"]: c["registration_date"] for c in customers}
    if len(cids) != len(customers): errs.append("duplicate customer_id")
    if len(pids) != len(products): errs.append("duplicate product_id")
    if len(oids) != len(orders): errs.append("duplicate order_id")
    if len({c["email"] for c in customers}) != len(customers): errs.append("duplicate email")
    if len({p["product_name"] for p in products}) != len(products): errs.append("duplicate product_name")
    sums = {}
    seen_pair = set()
    for it in items:
        if it["order_id"] not in oids: errs.append(f"item {it['order_item_id']} bad order"); break
        if it["product_id"] not in pids: errs.append(f"item {it['order_item_id']} bad product"); break
        if (it["order_id"], it["product_id"]) in seen_pair: errs.append("duplicate product within order"); break
        seen_pair.add((it["order_id"], it["product_id"]))
        if line_total(it["quantity"], it["unit_price"], it["discount_percentage"]) != it["line_total"]:
            errs.append(f"item {it['order_item_id']} line_total"); break
        sums[it["order_id"]] = sums.get(it["order_id"], Decimal(0)) + it["line_total"]
    for o in orders:
        if o["customer_id"] not in cids: errs.append(f"order {o['order_id']} bad customer"); break
        if o["order_id"] not in sums: errs.append(f"order {o['order_id']} has no items"); break
        if sums[o["order_id"]] + o["delivery_fee"] != o["total_amount"]:
            errs.append(f"order {o['order_id']} total mismatch"); break
        if not (DATA_START <= o["order_date"] <= DATA_END): errs.append("order date range"); break
        if o["order_date"].date() < reg[o["customer_id"]]: errs.append("order before registration"); break
    tot = {o["order_id"]: o["total_amount"] for o in orders}
    pay_orders = set()
    refs = set()
    for p in payments:
        if p["order_id"] not in oids: errs.append("payment bad order"); break
        if p["order_id"] in pay_orders: errs.append("two payments for one order"); break
        pay_orders.add(p["order_id"])
        if p["amount"] != tot[p["order_id"]]: errs.append("payment amount"); break
        if not (DATA_START <= p["payment_date"] <= DATA_END): errs.append("payment date range"); break
        r = p["transaction_reference"]
        if r is not None:
            if r in refs: errs.append("duplicate transaction_reference"); break
            refs.add(r)
    for s in staging:
        if s["order_id"] not in oids: errs.append("staging bad order"); break
    if errs:
        sys.exit("VALIDATION FAILED: " + "; ".join(errs))


# ---------------------------------------------------------------------------
COLUMNS = {
    "customers": ["customer_id", "first_name", "last_name", "email", "phone_number", "county",
                  "registration_date", "customer_status"],
    "products": ["product_id", "product_name", "category", "brand", "unit_price", "cost_price",
                 "stock_quantity", "created_at", "product_status"],
    "orders": ["order_id", "customer_id", "order_date", "order_status", "shipping_county",
               "delivery_fee", "total_amount"],
    "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price",
                    "discount_percentage", "line_total"],
    "payments": ["payment_id", "order_id", "payment_date", "payment_method", "amount",
                 "payment_status", "transaction_reference"],
    "payment_staging": ["staging_id", "payment_id", "order_id", "payment_date", "payment_method",
                        "amount", "payment_status", "transaction_reference", "source_file", "loaded_at"],
}
LOAD_ORDER = ["customers", "products", "orders", "order_items", "payments", "payment_staging"]
IDENTITY = {"customers": "customer_id", "products": "product_id", "orders": "order_id",
            "order_items": "order_item_id", "payments": "payment_id", "payment_staging": "staging_id"}


def fmt(v):
    if v is None:
        return None
    if isinstance(v, datetime):
        return ts(v)
    if isinstance(v, date):
        return v.isoformat()
    return str(v)


def sql_lit(v):
    if v is None:
        return "NULL"
    if isinstance(v, (int, Decimal)):
        return str(v)
    return "'" + fmt(v).replace("'", "''") + "'"


def write_csvs(out, tables):
    os.makedirs(os.path.join(out, "datasets"), exist_ok=True)
    for name in LOAD_ORDER:
        path = os.path.join(out, "datasets", f"{name}.csv")
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh, lineterminator="\n")
            w.writerow(COLUMNS[name])
            for row in tables[name]:
                w.writerow(["" if row[c] is None else fmt(row[c]) for c in COLUMNS[name]])


SETVAL = ("SELECT setval(pg_get_serial_sequence('sokomart.{t}', '{c}'), "
          "(SELECT COALESCE(MAX({c}), 0) + 1 FROM sokomart.{t}), false);\n")


def write_copy_loader(out, counts):
    os.makedirs(os.path.join(out, "database"), exist_ok=True)
    path = os.path.join(out, "database", "04_insert_data.sql")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("-- =====================================================================\n"
                 "-- 04_insert_data.sql  -  load the SokoMart CSVs with \\copy\n"
                 "-- Generated by scripts/generate_dataset.py - do not edit by hand.\n"
                 "--\n"
                 "-- Run psql FROM INSIDE the database/ folder, because the paths below are\n"
                 "-- relative (../datasets/...):\n"
                 "--     cd database\n"
                 "--     psql -d luxdevhq_cohort9_advanced_sql -f 04_insert_data.sql\n"
                 "-- \\copy is a psql meta-command: the file is read by YOUR psql client, so it\n"
                 "-- works against a remote or Docker server without superuser rights.\n"
                 "-- Expected rows: " + ", ".join(f"{t} {counts[t]:,}" for t in LOAD_ORDER) + "\n"
                 "-- =====================================================================\n"
                 "\\set ON_ERROR_STOP on\n"
                 "SET search_path TO sokomart;\n\n"
                 "BEGIN;\n\n")
        for t in LOAD_ORDER:
            fh.write(f"\\echo loading {t} ...\n")
            fh.write(f"\\copy sokomart.{t} ({', '.join(COLUMNS[t])}) FROM '../datasets/{t}.csv' "
                     "WITH (FORMAT csv, HEADER true)\n")
        fh.write("\n-- Explicit ids were loaded, so move every identity sequence past them;\n"
                 "-- otherwise the next INSERT (e.g. sp_place_order) collides with id 1.\n")
        for t in LOAD_ORDER:
            fh.write(SETVAL.format(t=t, c=IDENTITY[t]))
        fh.write("\nCOMMIT;\n\nANALYZE sokomart.customers, sokomart.products, sokomart.orders, "
                 "sokomart.order_items, sokomart.payments, sokomart.payment_staging;\n"
                 "\\echo 04_insert_data.sql finished - now run 05_indexes.sql and 06_validation.sql\n")


def write_insert_loader(out, tables, counts, batch=500):
    path = os.path.join(out, "database", "04b_insert_data_inserts.sql")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("-- =====================================================================\n"
                 "-- 04b_insert_data_inserts.sql  -  INSERT-based alternative to 04_insert_data.sql\n"
                 "-- Generated by scripts/generate_dataset.py --inserts. Use it when \\copy is not\n"
                 "-- available (e.g. a GUI client such as DBeaver or pgAdmin's query tool).\n"
                 "-- It needs no CSV files and can be run from any folder. Slower than \\copy.\n"
                 "-- Expected rows: " + ", ".join(f"{t} {counts[t]:,}" for t in LOAD_ORDER) + "\n"
                 "-- =====================================================================\n"
                 "SET search_path TO sokomart;\n\nBEGIN;\n\n")
        for t in LOAD_ORDER:
            cols = COLUMNS[t]
            rows = tables[t]
            for i in range(0, len(rows), batch):
                fh.write(f"INSERT INTO sokomart.{t} ({', '.join(cols)}) VALUES\n")
                chunk = rows[i:i + batch]
                for j, r in enumerate(chunk):
                    fh.write("(" + ", ".join(sql_lit(r[c]) for c in cols) + ")")
                    fh.write(",\n" if j < len(chunk) - 1 else ";\n")
            fh.write("\n")
        for t in LOAD_ORDER:
            fh.write(SETVAL.format(t=t, c=IDENTITY[t]))
        fh.write("\nCOMMIT;\n\nANALYZE sokomart.customers, sokomart.products, sokomart.orders, "
                 "sokomart.order_items, sokomart.payments, sokomart.payment_staging;\n")
    return path


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    pkg = os.path.dirname(here)
    ap = argparse.ArgumentParser(description="Generate the SokoMart Kenya synthetic dataset.")
    ap.add_argument("--seed", type=int, default=20261109)
    ap.add_argument("--customers", type=int, default=5000)
    ap.add_argument("--products", type=int, default=300)
    ap.add_argument("--orders", type=int, default=50000)
    ap.add_argument("--order-items", type=int, default=120000)
    ap.add_argument("--sample", action="store_true",
                    help="small dataset (200 customers, 60 products, 1,000 orders, 2,400 items) "
                         "written to ./sample_build unless --output-dir is given")
    ap.add_argument("--inserts", action="store_true",
                    help="also write database/04b_insert_data_inserts.sql (plain INSERTs)")
    ap.add_argument("--output-dir", default=None,
                    help="where datasets/ and database/04*.sql are written (default: package root)")
    args = ap.parse_args()
    if args.sample:
        args.customers, args.products, args.orders, args.order_items = 200, 60, 1000, 2400
    out = args.output_dir or (os.path.join(pkg, "sample_build") if args.sample else pkg)

    print(f"Generating: customers={args.customers:,} products={args.products:,} "
          f"orders={args.orders:,} order_items={args.order_items:,} seed={args.seed}")
    customers, products, orders, items, payments, staging = build(args)
    validate(customers, products, orders, items, payments, staging)
    tables = {"customers": customers, "products": products, "orders": orders,
              "order_items": items, "payments": payments, "payment_staging": staging}
    counts = {t: len(v) for t, v in tables.items()}
    write_csvs(out, tables)
    write_copy_loader(out, counts)
    if args.inserts:
        write_insert_loader(out, tables, counts)
    print("Validation passed. Rows written:")
    for t in LOAD_ORDER:
        print(f"  {t:<16} {counts[t]:>8,}")
    core = sum(counts[t] for t in LOAD_ORDER if t != "payment_staging")
    print(f"  {'core total':<16} {core:>8,}   (payment_staging is extra)")
    print(f"Output: {out}")


if __name__ == "__main__":
    main()
