# SokoMart Kenya — Advanced SQL Practical Project

**LuxDevHQ · Cohort 9 · Monday 9 – Thursday 12 November 2026**
**Deadline: Thursday 12 November 2026, 11:59 PM EAT — submit on Squad → Project Lab**

SokoMart Kenya is a (fictional) Kenyan online shop selling **electronics, groceries, fashion, home
appliances and beauty** products to customers in 14 counties, from Nairobi and Mombasa to Eldoret
(Uasin Gishu), Kisumu, Kericho and Nyeri. You get its database — 22 months of trading, January 2025
to October 2026 — and 25 hands-on questions from the business that you answer with **subqueries,
CTEs, window functions, views, functions, stored procedures, triggers, indexes and transactions**.

Every name, email, phone number and transaction in this package is **synthetic**. Emails use
`@example.co.ke` / `@sokomart-demo.ke`; phone numbers look like `07XX 555 XXX`.

## What is in the package

```
LuxDevHQ_Cohort9_Advanced_SQL/
├── README.md                          <- you are here
├── requirements.txt                   <- Faker, only needed to regenerate the data
├── datasets/                          <- the data as CSV (loaded by database/04_insert_data.sql)
│   ├── customers.csv        5,000
│   ├── products.csv           300
│   ├── orders.csv          50,000
│   ├── order_items.csv    120,000
│   ├── payments.csv        50,000
│   └── payment_staging.csv  2,640     (raw payment files with duplicates, for Question 24)
├── database/
│   ├── 01_create_database.sql         <- run alone, connected to "postgres"
│   ├── 02_create_schema.sql
│   ├── 03_create_tables.sql           <- keys, constraints
│   ├── 04_insert_data.sql             <- \copy loader: run psql FROM the database/ folder
│   ├── 04b_insert_data_inserts.sql    <- same data as plain INSERTs, for GUI tools
│   ├── 05_indexes.sql                 <- separate on purpose (Questions 21-22)
│   ├── 06_validation.sql              <- 41 PASS/FAIL checks
│   └── 07_reset_database.sql          <- drops and recreates ONLY the sokomart schema
├── scripts/generate_dataset.py        <- the deterministic generator that made all of the above
├── assignments/
│   ├── advanced_sql_questions.md      <- the 4-day plan, 10 drills, 25 questions
│   └── submission_guidelines.md       <- what to hand in, repo layout, checklist
├── docs/
│   ├── database_setup.md              <- step-by-step setup, Docker, troubleshooting
│   ├── database_relationships.md      <- ER diagram, keys, join paths
│   └── data_dictionary.md             <- every column, the revenue rule, business rules
└── sample_queries/connection_test.sql
```

Core tables: **225,300 rows** (customers 5,000 + products 300 + orders 50,000 + order_items 120,000 +
payments 50,000), plus 2,640 rows in `payment_staging`. Supporting tables `product_price_history`,
`order_status_history` and `audit_logs` start empty — your procedures and trigger fill them.

## Quick start

You need PostgreSQL 14+ (tested on 17) and `psql`. Connection details come from psql flags or the
`PGHOST` / `PGPORT` / `PGUSER` environment variables — **no passwords are stored anywhere in this
project**, and none should be in your submission. Full instructions: [`docs/database_setup.md`](docs/database_setup.md).

```bash
cd LuxDevHQ_Cohort9_Advanced_SQL/database          # important: 04 uses paths relative to this folder
psql -d postgres -f 01_create_database.sql          # on its own (CREATE DATABASE can't run in a transaction)
psql -d luxdevhq_cohort9_advanced_sql -f 02_create_schema.sql
psql -d luxdevhq_cohort9_advanced_sql -f 03_create_tables.sql
psql -d luxdevhq_cohort9_advanced_sql -f 04_insert_data.sql     # or 04b_insert_data_inserts.sql
psql -d luxdevhq_cohort9_advanced_sql -f 05_indexes.sql
psql -d luxdevhq_cohort9_advanced_sql -f 06_validation.sql      # every row must say PASS
```

Inside psql, after `01`: `\c luxdevhq_cohort9_advanced_sql`, then `\i 02_create_schema.sql` and so on.

**Start again at any time** (Sections D and E change data):

```bash
psql -d luxdevhq_cohort9_advanced_sql -f 07_reset_database.sql   # drops only schema sokomart
# then 03, 04, 05, 06 again
```

## The revenue rule

Use it in every question:

- **Revenue** = `SUM(order_items.line_total)` for orders with `order_status = 'completed'`.
- **Cost** = `SUM(order_items.quantity * products.cost_price)` for the same lines; **gross profit** = revenue − cost.
- Delivery fees, pending, cancelled and returned orders are **not** revenue.
- `payments.amount` is for payment analysis (success rates, reconciliation) — **not** revenue.

Why: an order only becomes money SokoMart keeps once it is delivered and paid (`completed`); a
returned order was refunded; delivery fees go to the courier. Details and every other business rule
(delivery fees, discounts, statuses) are in [`docs/data_dictionary.md`](docs/data_dictionary.md).

## The data, in one paragraph

5,000 customers, some of whom have never ordered; a few hundred heavy buyers and a long tail of
occasional ones. 300 products in 5 categories, some never ordered (new arrivals, discontinued and
out-of-stock lines). Electronics brings most of the revenue at thin margins; fashion and beauty
margins are three times higher. Nairobi dominates, with clear differences between counties.
December and November (Black Friday) are the peaks, with smaller back-to-school peaks in January,
May and August. Most payments are M-Pesa; around one in ten fails. `order_items.line_total` and
`orders.total_amount` always add up (`06_validation.sql` proves it).

## The four days

| Day | Work |
|---|---|
| Mon 9 Nov | Setup, validation, the 10 practice drills, **Section A** (CTEs and subqueries) |
| Tue 10 Nov | **Section B** (window functions) |
| Wed 11 Nov | **Section C** (advanced aggregation with subqueries) and **Section D** (views, functions, stored procedures, triggers) |
| Thu 12 Nov | **Section E** (optimisation and transactions), README, business insights, submission by **11:59 PM EAT** |

Questions: [`assignments/advanced_sql_questions.md`](assignments/advanced_sql_questions.md) ·
How to submit: [`assignments/submission_guidelines.md`](assignments/submission_guidelines.md)

## Regenerating the data (optional)

You never need to — the CSVs and both loaders are included. But the generator is part of the lesson:

```bash
cd LuxDevHQ_Cohort9_Advanced_SQL
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python3 scripts/generate_dataset.py --inserts          # identical files (fixed seed 20261109)
python3 scripts/generate_dataset.py --sample --inserts # small copy (200 customers, 1,000 orders) in ./sample_build/
python3 scripts/generate_dataset.py --help             # --seed, --customers, --products, --orders, --order-items, --output-dir
```

It checks every relationship and total before writing anything, and streams rows to disk. With other
counts or another seed the questions' expected numbers change, and the count checks in `06_validation.sql`
report FAIL by design (the integrity checks still apply).

## Getting help

Ask in the Cohort 9 channel on Squad. Include the question number, your SQL, and the full error
message. Do not post solutions.
