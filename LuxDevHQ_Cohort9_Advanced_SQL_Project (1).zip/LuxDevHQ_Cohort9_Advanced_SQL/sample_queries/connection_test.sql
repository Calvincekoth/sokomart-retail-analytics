-- =====================================================================
-- connection_test.sql  -  "am I connected to the right place, and is the data there?"
-- Run after loading (any folder):
--     psql -d luxdevhq_cohort9_advanced_sql -f sample_queries/connection_test.sql
-- =====================================================================
SELECT current_database()                       AS database,
       current_user                             AS connected_as,
       current_setting('search_path')           AS search_path,
       split_part(version(), ' ', 2)            AS postgres_version;

SELECT 'customers'   AS table_name, COUNT(*) AS row_count FROM sokomart.customers   UNION ALL
SELECT 'products',                  COUNT(*)              FROM sokomart.products    UNION ALL
SELECT 'orders',                    COUNT(*)              FROM sokomart.orders      UNION ALL
SELECT 'order_items',               COUNT(*)              FROM sokomart.order_items UNION ALL
SELECT 'payments',                  COUNT(*)              FROM sokomart.payments    UNION ALL
SELECT 'payment_staging',           COUNT(*)              FROM sokomart.payment_staging
ORDER BY table_name;

-- A first look at the business: completed revenue per category (the revenue rule).
SELECT p.category,
       COUNT(DISTINCT o.order_id) AS completed_orders,
       SUM(i.line_total)          AS revenue
FROM sokomart.orders o
JOIN sokomart.order_items i ON i.order_id = o.order_id
JOIN sokomart.products p    ON p.product_id = i.product_id
WHERE o.order_status = 'completed'
GROUP BY p.category
ORDER BY revenue DESC;

-- Five most recent orders
SELECT o.order_id, o.order_date, c.first_name || ' ' || c.last_name AS customer,
       o.shipping_county, o.order_status, o.total_amount
FROM sokomart.orders o
JOIN sokomart.customers c ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC
LIMIT 5;
